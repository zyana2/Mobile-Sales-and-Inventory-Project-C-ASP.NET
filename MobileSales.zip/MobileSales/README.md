# MobilePro – Mobile Sales & Services Management System

## Tech Stack
- **Frontend**: HTML5, Bootstrap 5.3, Vanilla JavaScript, Chart.js
- **Backend**: C# ASP.NET Core 8 Web API (MVC pattern)
- **Database**: SQL Server (LocalDB for dev, Azure SQL / full SQL Server for prod)
- **Auth**: JWT Bearer Tokens + BCrypt password hashing
- **ORM**: Entity Framework Core 8

---

## Project Structure

```
MobileSales/
├── frontend/
│   ├── index.html          ← Login page
│   ├── dashboard.html
│   ├── customers.html
│   ├── products.html
│   ├── sales.html
│   ├── purchases.html
│   ├── expenses.html
│   ├── inventory.html
│   ├── employees.html
│   ├── users.html          ← Admin only
│   ├── profile.html
│   ├── css/
│   │   ├── login.css
│   │   └── main.css
│   └── js/
│       ├── api.js          ← Central API layer
│       ├── app.js          ← Layout, auth guard, helpers
│       ├── login.js
│       ├── dashboard.js
│       ├── customers.js
│       ├── products.js
│       ├── sales.js
│       ├── purchases.js
│       ├── expenses.js
│       ├── inventory.js
│       ├── employees.js
│       ├── users.js
│       └── profile.js
│
└── backend/
    └── MobileSales.API/
        ├── Controllers/
        │   ├── AuthController.cs
        │   ├── UsersController.cs
        │   ├── ProfileController.cs
        │   └── BusinessControllers.cs  ← All business endpoints
        ├── Models/
        │   ├── User.cs
        │   ├── UserProfile.cs
        │   └── BusinessModels.cs
        ├── Services/
        │   ├── AuthService.cs
        │   ├── UserService.cs
        │   ├── ProfileService.cs
        │   ├── BusinessServices.cs
        │   └── DashboardService.cs
        ├── Data/
        │   ├── AppDbContext.cs
        │   └── DbSeeder.cs
        ├── Program.cs
        └── appsettings.json
```

---

## Setup & Run

### Backend

1. **Prerequisites**: .NET 8 SDK, SQL Server (LocalDB included with VS)

2. **Restore packages**
   ```
   cd backend/MobileSales.API
   dotnet restore
   ```

3. **Apply migrations** (creates the database)
   ```
   dotnet ef migrations add InitialCreate
   dotnet ef database update
   ```

4. **Run the API**
   ```
   dotnet run
   ```
   API runs at: `https://localhost:7001`
   Swagger UI: `https://localhost:7001/swagger`

### Frontend

1. Open `frontend/` folder with **Live Server** (VS Code extension) or any static server.
2. Default URL: `http://127.0.0.1:5500`
3. Update `API_BASE` in `js/api.js` if your backend URL differs.

---

## Default Login

| Username | Password  | Role  |
|----------|-----------|-------|
| admin    | Admin@123 | Admin |

> Admin will NOT be forced to change password on first login (seeded with `MustChangePassword = false`).
> New users created by admin WILL be forced to change password on first login.

---

## User Roles & Permissions

| Feature          | Admin | Manager | Employee | Viewer |
|------------------|-------|---------|----------|--------|
| Dashboard        | ✅    | ✅      | ✅       | ✅     |
| Sales (CRUD)     | ✅    | ✅      | ✅       | 👁️     |
| Purchases        | ✅    | ✅      | ❌       | ❌     |
| Expenses         | ✅    | ✅      | ❌       | ❌     |
| Products         | ✅    | ✅      | 👁️       | 👁️     |
| Inventory        | ✅    | ✅      | 👁️       | 👁️     |
| Customers        | ✅    | ✅      | ✅       | 👁️     |
| Employees        | ✅    | ✅      | ❌       | ❌     |
| User Management  | ✅    | ❌      | ❌       | ❌     |
| Profile          | ✅    | ✅      | ✅       | ✅     |

---

## REST API Endpoints

```
POST   /api/auth/login
POST   /api/auth/change-password
POST   /api/auth/logout

GET    /api/users
POST   /api/users
PUT    /api/users/{id}
DELETE /api/users/{id}
POST   /api/users/{id}/reset-password

GET    /api/profile
PUT    /api/profile
POST   /api/profile/education
PUT    /api/profile/education/{id}
DELETE /api/profile/education/{id}
POST   /api/profile/experience
PUT    /api/profile/experience/{id}
DELETE /api/profile/experience/{id}

GET/POST/PUT/DELETE  /api/employees
GET/POST/PUT/DELETE  /api/customers
GET/POST/PUT/DELETE  /api/products
GET/POST/PUT/DELETE  /api/sales
GET/POST/PUT/DELETE  /api/purchases
GET/POST/PUT/DELETE  /api/expenses

GET    /api/inventory
GET    /api/inventory/low-stock
PUT    /api/inventory/{id}

GET    /api/dashboard/stats
GET    /api/dashboard/sales-chart
GET    /api/dashboard/top-products
```

---

## Deployment

### Backend (Render / Azure App Service)
1. Publish: `dotnet publish -c Release`
2. Update `appsettings.json` connection string to production SQL Server
3. Update `AllowedOrigins` to your frontend domain

### Frontend (Netlify / Vercel / GitHub Pages)
1. Update `API_BASE` in `js/api.js` to your deployed API URL
2. Deploy the `frontend/` folder

---

## Features Implemented
- ✅ MVC Architecture
- ✅ JWT Role-based Authentication
- ✅ Separate dashboards per role (sidebar adapts)
- ✅ Admin user management + password generation
- ✅ Force password change on first login
- ✅ Full profile management (personal, education, experience)
- ✅ Left sidebar navigation
- ✅ Dashboard stat cards + Chart.js charts
- ✅ Employees, Customers, Products, Sales, Purchases, Expenses, Inventory
- ✅ CRUD for all modules
- ✅ Stock tracking (auto-deduct on sale, auto-add on purchase)
- ✅ Low stock alerts
- ✅ REST APIs with Swagger documentation
- ✅ Input validation (frontend + backend)
- ✅ Responsive Bootstrap 5 UI
- ✅ Toast notifications
- ✅ Confirm dialogs for destructive actions
