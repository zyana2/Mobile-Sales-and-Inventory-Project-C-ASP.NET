using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MobileSales.API.Services;
using System.Security.Claims;

namespace MobileSales.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController(IAuthService authService) : ControllerBase
{
    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.Username) || string.IsNullOrWhiteSpace(req.Password))
            return BadRequest(new { message = "Username and password are required." });

        var result = await authService.LoginAsync(req.Username, req.Password);
        if (result is null)
            return Unauthorized(new { message = "Invalid username or password." });

        return Ok(new { token = result.Token, user = result.User });
    }

    [HttpPost("change-password")]
    [Authorize]
    public async Task<IActionResult> ChangePassword([FromBody] ChangePasswordRequest req)
    {
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

        if (req.NewPassword.Length < 8)
            return BadRequest(new { message = "Password must be at least 8 characters." });

        var success = await authService.ChangePasswordAsync(userId, req.CurrentPassword, req.NewPassword);
        if (!success)
            return BadRequest(new { message = "Current password is incorrect." });

        return Ok(new { message = "Password changed successfully." });
    }

    [HttpPost("logout")]
    [Authorize]
    public async Task<IActionResult> Logout()
    {
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        await authService.LogoutAsync(userId);
        return Ok(new { message = "Logged out." });
    }
}

public record LoginRequest(string Username, string Password);
public record ChangePasswordRequest(string? CurrentPassword, string NewPassword, int? UserId);
