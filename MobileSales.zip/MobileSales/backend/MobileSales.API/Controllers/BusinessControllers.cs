using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MobileSales.API.Models;
using MobileSales.API.Services;

namespace MobileSales.API.Controllers;

// ═══════════════════════════════════════════════════════════════════════════════
// EMPLOYEES
// ═══════════════════════════════════════════════════════════════════════════════
[ApiController, Route("api/[controller]"), Authorize(Roles = "Admin,Manager")]
public class EmployeesController(IEmployeeService svc) : ControllerBase
{
    [HttpGet]    public async Task<IActionResult> GetAll()          => Ok(await svc.GetAllAsync());
    [HttpGet("{id:int}")] public async Task<IActionResult> GetById(int id) { var r = await svc.GetByIdAsync(id); return r is null ? NotFound() : Ok(r); }
    [HttpPost]   public async Task<IActionResult> Create([FromBody] Employee e)  => Ok(await svc.CreateAsync(e));
    [HttpPut("{id:int}")] public async Task<IActionResult> Update(int id, [FromBody] Employee e) { var r = await svc.UpdateAsync(id, e); return r is null ? NotFound() : Ok(r); }
    [HttpDelete("{id:int}")] public async Task<IActionResult> Delete(int id) { var ok = await svc.DeleteAsync(id); return ok ? NoContent() : NotFound(); }
}

// ═══════════════════════════════════════════════════════════════════════════════
// CUSTOMERS
// ═══════════════════════════════════════════════════════════════════════════════
[ApiController, Route("api/[controller]"), Authorize]
public class CustomersController(ICustomerService svc) : ControllerBase
{
    [HttpGet]    public async Task<IActionResult> GetAll()          => Ok(await svc.GetAllAsync());
    [HttpGet("{id:int}")] public async Task<IActionResult> GetById(int id) { var r = await svc.GetByIdAsync(id); return r is null ? NotFound() : Ok(r); }
    [HttpPost]   public async Task<IActionResult> Create([FromBody] Customer c)  => Ok(await svc.CreateAsync(c));
    [HttpPut("{id:int}")] public async Task<IActionResult> Update(int id, [FromBody] Customer c) { var r = await svc.UpdateAsync(id, c); return r is null ? NotFound() : Ok(r); }
    [HttpDelete("{id:int}")] [Authorize(Roles = "Admin,Manager")] public async Task<IActionResult> Delete(int id) { var ok = await svc.DeleteAsync(id); return ok ? NoContent() : NotFound(); }
}

// ═══════════════════════════════════════════════════════════════════════════════
// PRODUCTS
// ═══════════════════════════════════════════════════════════════════════════════
[ApiController, Route("api/[controller]"), Authorize]
public class ProductsController(IProductService svc) : ControllerBase
{
    [HttpGet]    public async Task<IActionResult> GetAll()          => Ok(await svc.GetAllAsync());
    [HttpGet("{id:int}")] public async Task<IActionResult> GetById(int id) { var r = await svc.GetByIdAsync(id); return r is null ? NotFound() : Ok(r); }
    [HttpPost]   [Authorize(Roles = "Admin,Manager")] public async Task<IActionResult> Create([FromBody] Product p) => Ok(await svc.CreateAsync(p));
    [HttpPut("{id:int}")] [Authorize(Roles = "Admin,Manager")] public async Task<IActionResult> Update(int id, [FromBody] Product p) { var r = await svc.UpdateAsync(id, p); return r is null ? NotFound() : Ok(r); }
    [HttpDelete("{id:int}")] [Authorize(Roles = "Admin")] public async Task<IActionResult> Delete(int id) { var ok = await svc.DeleteAsync(id); return ok ? NoContent() : NotFound(); }
}

// ═══════════════════════════════════════════════════════════════════════════════
// SALES
// ═══════════════════════════════════════════════════════════════════════════════
[ApiController, Route("api/[controller]"), Authorize]
public class SalesController(ISaleService svc) : ControllerBase
{
    [HttpGet]    public async Task<IActionResult> GetAll()          => Ok(await svc.GetAllAsync());
    [HttpGet("{id:int}")] public async Task<IActionResult> GetById(int id) { var r = await svc.GetByIdAsync(id); return r is null ? NotFound() : Ok(r); }
    [HttpPost]   public async Task<IActionResult> Create([FromBody] Sale s)  => Ok(await svc.CreateAsync(s));
    [HttpPut("{id:int}")] public async Task<IActionResult> Update(int id, [FromBody] Sale s) { var r = await svc.UpdateAsync(id, s); return r is null ? NotFound() : Ok(r); }
    [HttpDelete("{id:int}")] [Authorize(Roles = "Admin,Manager")] public async Task<IActionResult> Delete(int id) { var ok = await svc.DeleteAsync(id); return ok ? NoContent() : NotFound(); }
}

// ═══════════════════════════════════════════════════════════════════════════════
// PURCHASES
// ═══════════════════════════════════════════════════════════════════════════════
[ApiController, Route("api/[controller]"), Authorize(Roles = "Admin,Manager")]
public class PurchasesController(IPurchaseService svc) : ControllerBase
{
    [HttpGet]    public async Task<IActionResult> GetAll()          => Ok(await svc.GetAllAsync());
    [HttpGet("{id:int}")] public async Task<IActionResult> GetById(int id) { var r = await svc.GetByIdAsync(id); return r is null ? NotFound() : Ok(r); }
    [HttpPost]   public async Task<IActionResult> Create([FromBody] Purchase p) => Ok(await svc.CreateAsync(p));
    [HttpPut("{id:int}")] public async Task<IActionResult> Update(int id, [FromBody] Purchase p) { var r = await svc.UpdateAsync(id, p); return r is null ? NotFound() : Ok(r); }
    [HttpDelete("{id:int}")] public async Task<IActionResult> Delete(int id) { var ok = await svc.DeleteAsync(id); return ok ? NoContent() : NotFound(); }
}

// ═══════════════════════════════════════════════════════════════════════════════
// EXPENSES
// ═══════════════════════════════════════════════════════════════════════════════
[ApiController, Route("api/[controller]"), Authorize(Roles = "Admin,Manager")]
public class ExpensesController(IExpenseService svc) : ControllerBase
{
    [HttpGet]    public async Task<IActionResult> GetAll()          => Ok(await svc.GetAllAsync());
    [HttpGet("{id:int}")] public async Task<IActionResult> GetById(int id) { var r = await svc.GetByIdAsync(id); return r is null ? NotFound() : Ok(r); }
    [HttpPost]   public async Task<IActionResult> Create([FromBody] Expense e) => Ok(await svc.CreateAsync(e));
    [HttpPut("{id:int}")] public async Task<IActionResult> Update(int id, [FromBody] Expense e) { var r = await svc.UpdateAsync(id, e); return r is null ? NotFound() : Ok(r); }
    [HttpDelete("{id:int}")] public async Task<IActionResult> Delete(int id) { var ok = await svc.DeleteAsync(id); return ok ? NoContent() : NotFound(); }
}

// ═══════════════════════════════════════════════════════════════════════════════
// INVENTORY
// ═══════════════════════════════════════════════════════════════════════════════
[ApiController, Route("api/[controller]"), Authorize]
public class InventoryController(IInventoryService svc) : ControllerBase
{
    [HttpGet]    public async Task<IActionResult> GetAll()          => Ok(await svc.GetAllAsync());
    [HttpGet("{id:int}")] public async Task<IActionResult> GetById(int id) { var r = await svc.GetByIdAsync(id); return r is null ? NotFound() : Ok(r); }
    [HttpGet("low-stock")] public async Task<IActionResult> GetLowStock() => Ok(await svc.GetLowStockAsync());
    [HttpPut("{id:int}")] [Authorize(Roles = "Admin,Manager")] public async Task<IActionResult> Update(int id, [FromBody] AdjustStockRequest req)
    {
        var r = await svc.UpdateStockAsync(id, req.CurrentStock, req.Reason);
        return r is null ? NotFound() : Ok(r);
    }
}

public record AdjustStockRequest(int CurrentStock, string? Reason);

// ═══════════════════════════════════════════════════════════════════════════════
// DASHBOARD
// ═══════════════════════════════════════════════════════════════════════════════
[ApiController, Route("api/[controller]"), Authorize]
public class DashboardController(IDashboardService svc) : ControllerBase
{
    [HttpGet("stats")]        public async Task<IActionResult> GetStats()      => Ok(await svc.GetStatsAsync());
    [HttpGet("sales-chart")]  public async Task<IActionResult> GetSalesChart() => Ok(await svc.GetSalesChartAsync());
    [HttpGet("top-products")] public async Task<IActionResult> GetTopProducts()=> Ok(await svc.GetTopProductsAsync());
}
