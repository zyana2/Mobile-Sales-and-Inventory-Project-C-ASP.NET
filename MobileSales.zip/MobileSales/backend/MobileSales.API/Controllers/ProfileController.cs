using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MobileSales.API.Models;
using MobileSales.API.Services;
using System.Security.Claims;

namespace MobileSales.API.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ProfileController(IProfileService profileService) : ControllerBase
{
    private int UserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    [HttpGet]
    public async Task<IActionResult> Get()
    {
        var profile = await profileService.GetByUserIdAsync(UserId);
        return profile is null ? NotFound() : Ok(profile);
    }

    [HttpPut]
    public async Task<IActionResult> Update([FromBody] UpdateProfileRequest req)
    {
        var result = await profileService.UpdateAsync(UserId, req);
        return result is null ? NotFound() : Ok(result);
    }

    // ── Education ──────────────────────────────────────────────────────────────
    [HttpPost("education")]
    public async Task<IActionResult> AddEducation([FromBody] Education edu)
    {
        var result = await profileService.AddEducationAsync(UserId, edu);
        return Ok(result);
    }

    [HttpPut("education/{id:int}")]
    public async Task<IActionResult> UpdateEducation(int id, [FromBody] Education edu)
    {
        var result = await profileService.UpdateEducationAsync(id, UserId, edu);
        return result is null ? NotFound() : Ok(result);
    }

    [HttpDelete("education/{id:int}")]
    public async Task<IActionResult> DeleteEducation(int id)
    {
        var success = await profileService.DeleteEducationAsync(id, UserId);
        return success ? NoContent() : NotFound();
    }

    // ── Experience ─────────────────────────────────────────────────────────────
    [HttpPost("experience")]
    public async Task<IActionResult> AddExperience([FromBody] Experience exp)
    {
        var result = await profileService.AddExperienceAsync(UserId, exp);
        return Ok(result);
    }

    [HttpPut("experience/{id:int}")]
    public async Task<IActionResult> UpdateExperience(int id, [FromBody] Experience exp)
    {
        var result = await profileService.UpdateExperienceAsync(id, UserId, exp);
        return result is null ? NotFound() : Ok(result);
    }

    [HttpDelete("experience/{id:int}")]
    public async Task<IActionResult> DeleteExperience(int id)
    {
        var success = await profileService.DeleteExperienceAsync(id, UserId);
        return success ? NoContent() : NotFound();
    }
}
