using Microsoft.EntityFrameworkCore;
using MobileSales.API.Models;

namespace MobileSales.API.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<User>            Users            => Set<User>();
    public DbSet<UserProfile>     UserProfiles     => Set<UserProfile>();
    public DbSet<Education>       Educations       => Set<Education>();
    public DbSet<Experience>      Experiences      => Set<Experience>();
    public DbSet<Course>          Courses          => Set<Course>();
    public DbSet<Project>         Projects         => Set<Project>();
    public DbSet<Employee>        Employees        => Set<Employee>();
    public DbSet<Customer>        Customers        => Set<Customer>();
    public DbSet<Product>         Products         => Set<Product>();
    public DbSet<Inventory>       Inventories      => Set<Inventory>();
    public DbSet<Sale>            Sales            => Set<Sale>();
    public DbSet<Purchase>        Purchases        => Set<Purchase>();
    public DbSet<Expense>         Expenses         => Set<Expense>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // User
        modelBuilder.Entity<User>()
            .HasIndex(u => u.Username).IsUnique();

        // UserProfile 1-to-1 with User
        modelBuilder.Entity<UserProfile>()
            .HasOne(p => p.User)
            .WithOne(u => u.Profile)
            .HasForeignKey<UserProfile>(p => p.UserId);

        // Education -> UserProfile
        modelBuilder.Entity<Education>()
            .HasOne(e => e.UserProfile)
            .WithMany(p => p.Educations)
            .HasForeignKey(e => e.UserProfileId);

        // Experience -> UserProfile
        modelBuilder.Entity<Experience>()
            .HasOne(e => e.UserProfile)
            .WithMany(p => p.Experiences)
            .HasForeignKey(e => e.UserProfileId);

        // Course -> UserProfile
        modelBuilder.Entity<Course>()
            .HasOne(c => c.UserProfile)
            .WithMany(p => p.Courses)
            .HasForeignKey(c => c.UserProfileId);

        // Project -> UserProfile
        modelBuilder.Entity<Project>()
            .HasOne(p => p.UserProfile)
            .WithMany(up => up.Projects)
            .HasForeignKey(p => p.UserProfileId);

        // Sale -> Customer, Product
        modelBuilder.Entity<Sale>()
            .HasOne(s => s.Customer)
            .WithMany(c => c.Sales)
            .HasForeignKey(s => s.CustomerId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Sale>()
            .HasOne(s => s.Product)
            .WithMany(p => p.Sales)
            .HasForeignKey(s => s.ProductId)
            .OnDelete(DeleteBehavior.Restrict);

        // Purchase -> Product
        modelBuilder.Entity<Purchase>()
            .HasOne(p => p.Product)
            .WithMany(pr => pr.Purchases)
            .HasForeignKey(p => p.ProductId)
            .OnDelete(DeleteBehavior.Restrict);

        // Inventory -> Product (1-to-1)
        modelBuilder.Entity<Inventory>()
            .HasOne(i => i.Product)
            .WithOne(p => p.Inventory)
            .HasForeignKey<Inventory>(i => i.ProductId);

        // Decimal precision
        foreach (var entity in modelBuilder.Model.GetEntityTypes())
        {
            foreach (var prop in entity.GetProperties()
                .Where(p => p.ClrType == typeof(decimal) || p.ClrType == typeof(decimal?)))
            {
                prop.SetPrecision(18);
                prop.SetScale(2);
            }
        }
    }
}
