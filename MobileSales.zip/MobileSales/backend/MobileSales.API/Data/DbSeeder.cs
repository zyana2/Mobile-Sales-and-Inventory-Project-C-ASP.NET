using MobileSales.API.Models;

namespace MobileSales.API.Data;

public static class DbSeeder
{
    public static async Task SeedAsync(AppDbContext db)
    {
        // Seed admin user if no users exist
        if (!db.Users.Any())
        {
            var admin = new User
            {
                Username          = "admin",
                PasswordHash      = BCrypt.Net.BCrypt.HashPassword("Admin@123"),
                FullName          = "System Administrator",
                Email             = "admin@mobilepro.com",
                Role              = "Admin",
                Status            = "Active",
                MustChangePassword = false,
                CreatedAt         = DateTime.UtcNow,
            };
            db.Users.Add(admin);
            await db.SaveChangesAsync();

            // Create profile for admin
            db.UserProfiles.Add(new UserProfile
            {
                UserId    = admin.Id,
                City      = "Karachi",
                CreatedAt = DateTime.UtcNow,
            });
            await db.SaveChangesAsync();
        }

        // Seed sample products if none exist
        if (!db.Products.Any())
        {
            var products = new List<Product>
            {
                new() { Name = "Samsung Galaxy A54", Category = "Smartphone", Brand = "Samsung", Model = "A54", BuyPrice = 55000, SellPrice = 62000, MinStock = 5, WarrantyMonths = 12, Status = "Active", CreatedAt = DateTime.UtcNow },
                new() { Name = "iPhone 14", Category = "Smartphone", Brand = "Apple", Model = "iPhone 14", BuyPrice = 180000, SellPrice = 195000, MinStock = 3, WarrantyMonths = 12, Status = "Active", CreatedAt = DateTime.UtcNow },
                new() { Name = "Xiaomi Redmi Note 12", Category = "Smartphone", Brand = "Xiaomi", Model = "Redmi Note 12", BuyPrice = 35000, SellPrice = 40000, MinStock = 10, WarrantyMonths = 12, Status = "Active", CreatedAt = DateTime.UtcNow },
                new() { Name = "Samsung Charger 25W", Category = "Accessory", Brand = "Samsung", Model = "EP-TA800", BuyPrice = 1500, SellPrice = 2500, MinStock = 20, WarrantyMonths = 6, Status = "Active", CreatedAt = DateTime.UtcNow },
                new() { Name = "Screen Protector Universal", Category = "Accessory", Brand = "Generic", Model = "Universal", BuyPrice = 200, SellPrice = 500, MinStock = 50, WarrantyMonths = 0, Status = "Active", CreatedAt = DateTime.UtcNow },
            };
            db.Products.AddRange(products);
            await db.SaveChangesAsync();

            // Create inventory for each product
            foreach (var p in products)
            {
                db.Inventories.Add(new Inventory
                {
                    ProductId    = p.Id,
                    CurrentStock = 20,
                    LastUpdated  = DateTime.UtcNow,
                });
            }
            await db.SaveChangesAsync();
        }
    }
}
