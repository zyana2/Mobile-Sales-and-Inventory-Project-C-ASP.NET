namespace MobileSales.API.Models;

// ── Employee ──────────────────────────────────────────────────────────────────
public class Employee
{
    public int       Id          { get; set; }
    public string    FullName    { get; set; } = string.Empty;
    public string?   Cnic        { get; set; }
    public string    Phone       { get; set; } = string.Empty;
    public string?   Email       { get; set; }
    public string?   Designation { get; set; }
    public string?   Department  { get; set; }
    public decimal   Salary      { get; set; }
    public DateTime? JoinDate    { get; set; }
    public string    Status      { get; set; } = "Active";
    public string?   Address     { get; set; }
    public DateTime  CreatedAt   { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt   { get; set; }
}

// ── Customer ──────────────────────────────────────────────────────────────────
public class Customer
{
    public int       Id        { get; set; }
    public string    FullName  { get; set; } = string.Empty;
    public string    Phone     { get; set; } = string.Empty;
    public string?   Email     { get; set; }
    public string?   Cnic      { get; set; }
    public string?   City      { get; set; }
    public string?   Address   { get; set; }
    public string?   Notes     { get; set; }
    public DateTime  CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }

    // Navigation
    public ICollection<Sale> Sales { get; set; } = [];
}

// ── Product ───────────────────────────────────────────────────────────────────
public class Product
{
    public int       Id              { get; set; }
    public string    Name            { get; set; } = string.Empty;
    public string    Category        { get; set; } = string.Empty;
    public string?   Brand           { get; set; }
    public string?   Model           { get; set; }
    public string?   Sku             { get; set; }
    public decimal   BuyPrice        { get; set; }
    public decimal   SellPrice       { get; set; }
    public int       MinStock        { get; set; } = 5;
    public int       WarrantyMonths  { get; set; } = 12;
    public string    Status          { get; set; } = "Active";
    public string?   Description     { get; set; }
    public DateTime  CreatedAt       { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt       { get; set; }

    // Navigation
    public Inventory?          Inventory { get; set; }
    public ICollection<Sale>   Sales     { get; set; } = [];
    public ICollection<Purchase> Purchases { get; set; } = [];
}

// ── Inventory ─────────────────────────────────────────────────────────────────
public class Inventory
{
    public int      Id           { get; set; }
    public int      ProductId    { get; set; }
    public int      CurrentStock { get; set; }
    public DateTime LastUpdated  { get; set; } = DateTime.UtcNow;

    // Navigation
    public Product Product { get; set; } = null!;
}

// ── Sale ──────────────────────────────────────────────────────────────────────
public class Sale
{
    public int       Id             { get; set; }
    public string    InvoiceNumber  { get; set; } = string.Empty;
    public int       CustomerId     { get; set; }
    public int       ProductId      { get; set; }
    public int       Quantity       { get; set; }
    public decimal   UnitPrice      { get; set; }
    public decimal   Discount       { get; set; }
    public decimal   TotalAmount    { get; set; }
    public decimal   Profit         { get; set; }
    public DateTime  SaleDate       { get; set; } = DateTime.UtcNow;
    public string    PaymentMethod  { get; set; } = "Cash";
    public string    Status         { get; set; } = "Completed";
    public string?   Notes          { get; set; }
    public DateTime  CreatedAt      { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt      { get; set; }

    // Navigation
    public Customer Customer { get; set; } = null!;
    public Product  Product  { get; set; } = null!;
}

// ── Purchase ──────────────────────────────────────────────────────────────────
public class Purchase
{
    public int       Id             { get; set; }
    public string    SupplierName   { get; set; } = string.Empty;
    public int       ProductId      { get; set; }
    public int       Quantity       { get; set; }
    public decimal   UnitCost       { get; set; }
    public decimal   TotalCost      { get; set; }
    public DateTime  PurchaseDate   { get; set; } = DateTime.UtcNow;
    public string?   InvoiceNumber  { get; set; }
    public string    Status         { get; set; } = "Received";
    public string?   Notes          { get; set; }
    public DateTime  CreatedAt      { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt      { get; set; }

    // Navigation
    public Product Product { get; set; } = null!;
}

// ── Expense ───────────────────────────────────────────────────────────────────
public class Expense
{
    public int       Id          { get; set; }
    public string    Title       { get; set; } = string.Empty;
    public string    Category    { get; set; } = "Other";
    public decimal   Amount      { get; set; }
    public DateTime  ExpenseDate { get; set; } = DateTime.UtcNow;
    public string?   PaidBy      { get; set; }
    public string?   Notes       { get; set; }
    public DateTime  CreatedAt   { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt   { get; set; }
}
