namespace MobileSales.API.Models;

public class User
{
    public int       Id                 { get; set; }
    public string    Username           { get; set; } = string.Empty;
    public string    PasswordHash       { get; set; } = string.Empty;
    public string    FullName           { get; set; } = string.Empty;
    public string?   Email              { get; set; }
    public string    Role               { get; set; } = "Employee"; // Admin | Manager | Employee | Viewer
    public string    Status             { get; set; } = "Active";   // Active | Inactive
    public bool      MustChangePassword { get; set; } = true;
    public DateTime? LastLogin          { get; set; }
    public DateTime  CreatedAt          { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt          { get; set; }

    // Navigation
    public UserProfile? Profile { get; set; }
}
