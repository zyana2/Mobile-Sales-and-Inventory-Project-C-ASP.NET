namespace MobileSales.API.Models;

public class UserProfile
{
    public int       Id          { get; set; }
    public int       UserId      { get; set; }
    public string?   Phone       { get; set; }
    public string?   Cnic        { get; set; }
    public DateTime? DateOfBirth { get; set; }
    public string?   City        { get; set; }
    public string?   Address     { get; set; }
    public string?   Bio         { get; set; }
    public DateTime  CreatedAt   { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt   { get; set; }

    // Navigation
    public User                User        { get; set; } = null!;
    public ICollection<Education>  Educations  { get; set; } = [];
    public ICollection<Experience> Experiences { get; set; } = [];
    public ICollection<Course>     Courses     { get; set; } = [];
    public ICollection<Project>    Projects    { get; set; } = [];
}

public class Education
{
    public int       Id            { get; set; }
    public int       UserProfileId { get; set; }
    public string    Degree        { get; set; } = string.Empty;
    public string    Institution   { get; set; } = string.Empty;
    public DateTime? FromDate      { get; set; }
    public DateTime? ToDate        { get; set; }
    public string?   Grade         { get; set; }
    public UserProfile UserProfile { get; set; } = null!;
}

public class Experience
{
    public int       Id            { get; set; }
    public int       UserProfileId { get; set; }
    public string    JobTitle      { get; set; } = string.Empty;
    public string    Company       { get; set; } = string.Empty;
    public DateTime? FromDate      { get; set; }
    public DateTime? ToDate        { get; set; }
    public bool      IsCurrent     { get; set; }
    public string?   Description   { get; set; }
    public UserProfile UserProfile { get; set; } = null!;
}

public class Course
{
    public int       Id             { get; set; }
    public int       UserProfileId  { get; set; }
    public string    CourseName     { get; set; } = string.Empty;
    public string?   Provider       { get; set; }
    public DateTime? CompletionDate { get; set; }
    public string?   CertificateUrl { get; set; }
    public UserProfile UserProfile  { get; set; } = null!;
}

public class Project
{
    public int       Id            { get; set; }
    public int       UserProfileId { get; set; }
    public string    Title         { get; set; } = string.Empty;
    public string?   Description   { get; set; }
    public string?   Url           { get; set; }
    public DateTime? StartDate     { get; set; }
    public DateTime? EndDate       { get; set; }
    public UserProfile UserProfile { get; set; } = null!;
}
