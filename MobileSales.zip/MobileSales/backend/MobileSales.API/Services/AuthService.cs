using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using MobileSales.API.Data;
using MobileSales.API.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace MobileSales.API.Services;

public interface IAuthService
{
    Task<LoginResult?> LoginAsync(string username, string password);
    Task<bool> ChangePasswordAsync(int userId, string? currentPassword, string newPassword, bool isFirstLogin = false);
    Task<bool> LogoutAsync(int userId);
}

public record LoginResult(string Token, UserDto User);

public class AuthService(AppDbContext db, IConfiguration config) : IAuthService
{
    public async Task<LoginResult?> LoginAsync(string username, string password)
    {
        var user = await db.Users
            .FirstOrDefaultAsync(u => u.Username == username && u.Status == "Active");

        if (user is null || !BCrypt.Net.BCrypt.Verify(password, user.PasswordHash))
            return null;

        user.LastLogin = DateTime.UtcNow;
        await db.SaveChangesAsync();

        var token = GenerateToken(user);
        var dto   = MapToDto(user);
        return new LoginResult(token, dto);
    }

    public async Task<bool> ChangePasswordAsync(int userId, string? currentPassword, string newPassword, bool isFirstLogin = false)
    {
        var user = await db.Users.FindAsync(userId);
        if (user is null) return false;

        if (!isFirstLogin && currentPassword is not null)
        {
            if (!BCrypt.Net.BCrypt.Verify(currentPassword, user.PasswordHash))
                return false;
        }

        user.PasswordHash      = BCrypt.Net.BCrypt.HashPassword(newPassword);
        user.MustChangePassword = false;
        user.UpdatedAt         = DateTime.UtcNow;
        await db.SaveChangesAsync();
        return true;
    }

    public async Task<bool> LogoutAsync(int userId)
    {
        // Stateless JWT — nothing to invalidate server-side
        // Could implement token blacklist here if needed
        await Task.CompletedTask;
        return true;
    }

    private string GenerateToken(User user)
    {
        var key     = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(config["Jwt:Key"]!));
        var creds   = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
        var expiry  = DateTime.UtcNow.AddHours(double.Parse(config["Jwt:ExpiryHours"] ?? "8"));

        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new Claim(ClaimTypes.Name,           user.Username),
            new Claim(ClaimTypes.Role,           user.Role),
            new Claim("fullName",                user.FullName),
        };

        var token = new JwtSecurityToken(
            issuer:   config["Jwt:Issuer"],
            audience: config["Jwt:Audience"],
            claims:   claims,
            expires:  expiry,
            signingCredentials: creds);

        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    private static UserDto MapToDto(User u) => new(
        u.Id, u.Username, u.FullName, u.Email, u.Role, u.Status, u.MustChangePassword, u.LastLogin);
}

public record UserDto(
    int Id, string Username, string FullName, string? Email,
    string Role, string Status, bool MustChangePassword, DateTime? LastLogin);
