using Microsoft.EntityFrameworkCore;
using MobileSales.API.Data;
using MobileSales.API.Models;

namespace MobileSales.API.Services;

// ═══════════════════════════════════════════════════════════════════════════════
// EMPLOYEE SERVICE
// ═══════════════════════════════════════════════════════════════════════════════
public interface IEmployeeService
{
    Task<List<Employee>> GetAllAsync();
    Task<Employee?> GetByIdAsync(int id);
    Task<Employee> CreateAsync(Employee emp);
    Task<Employee?> UpdateAsync(int id, Employee emp);
    Task<bool> DeleteAsync(int id);
}

public class EmployeeService(AppDbContext db) : IEmployeeService
{
    public Task<List<Employee>> GetAllAsync() => db.Employees.OrderByDescending(e => e.CreatedAt).ToListAsync();
    public Task<Employee?> GetByIdAsync(int id) => db.Employees.FindAsync(id).AsTask();

    public async Task<Employee> CreateAsync(Employee emp)
    {
        emp.CreatedAt = DateTime.UtcNow;
        db.Employees.Add(emp);
        await db.SaveChangesAsync();
        return emp;
    }

    public async Task<Employee?> UpdateAsync(int id, Employee emp)
    {
        var existing = await db.Employees.FindAsync(id);
        if (existing is null) return null;
        emp.Id = id; emp.UpdatedAt = DateTime.UtcNow; emp.CreatedAt = existing.CreatedAt;
        db.Entry(existing).CurrentValues.SetValues(emp);
        await db.SaveChangesAsync();
        return existing;
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var e = await db.Employees.FindAsync(id);
        if (e is null) return false;
        db.Employees.Remove(e); await db.SaveChangesAsync(); return true;
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// CUSTOMER SERVICE
// ═══════════════════════════════════════════════════════════════════════════════
public interface ICustomerService
{
    Task<List<CustomerDto>> GetAllAsync();
    Task<Customer?> GetByIdAsync(int id);
    Task<Customer> CreateAsync(Customer c);
    Task<Customer?> UpdateAsync(int id, Customer c);
    Task<bool> DeleteAsync(int id);
}

public class CustomerService(AppDbContext db) : ICustomerService
{
    public async Task<List<CustomerDto>> GetAllAsync()
    {
        return await db.Customers
            .Select(c => new CustomerDto(
                c.Id, c.FullName, c.Phone, c.Email, c.Cnic, c.City, c.Address, c.Notes,
                c.Sales.Where(s => s.Status == "Completed").Sum(s => s.TotalAmount),
                c.CreatedAt))
            .OrderByDescending(c => c.CreatedAt)
            .ToListAsync();
    }

    public Task<Customer?> GetByIdAsync(int id) => db.Customers.FindAsync(id).AsTask();

    public async Task<Customer> CreateAsync(Customer c)
    {
        c.CreatedAt = DateTime.UtcNow;
        db.Customers.Add(c); await db.SaveChangesAsync(); return c;
    }

    public async Task<Customer?> UpdateAsync(int id, Customer c)
    {
        var existing = await db.Customers.FindAsync(id);
        if (existing is null) return null;
        c.Id = id; c.UpdatedAt = DateTime.UtcNow; c.CreatedAt = existing.CreatedAt;
        db.Entry(existing).CurrentValues.SetValues(c);
        await db.SaveChangesAsync(); return existing;
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var c = await db.Customers.FindAsync(id);
        if (c is null) return false;
        db.Customers.Remove(c); await db.SaveChangesAsync(); return true;
    }
}

public record CustomerDto(int Id, string FullName, string Phone, string? Email, string? Cnic,
    string? City, string? Address, string? Notes, decimal TotalPurchases, DateTime CreatedAt);

// ═══════════════════════════════════════════════════════════════════════════════
// PRODUCT SERVICE
// ═══════════════════════════════════════════════════════════════════════════════
public interface IProductService
{
    Task<List<ProductDto>> GetAllAsync();
    Task<Product?> GetByIdAsync(int id);
    Task<Product> CreateAsync(Product p);
    Task<Product?> UpdateAsync(int id, Product p);
    Task<bool> DeleteAsync(int id);
}

public class ProductService(AppDbContext db) : IProductService
{
    public async Task<List<ProductDto>> GetAllAsync()
    {
        return await db.Products
            .Include(p => p.Inventory)
            .Select(p => new ProductDto(
                p.Id, p.Name, p.Category, p.Brand, p.Model, p.Sku,
                p.BuyPrice, p.SellPrice, p.MinStock, p.WarrantyMonths, p.Status, p.Description,
                p.Inventory != null ? p.Inventory.CurrentStock : 0, p.CreatedAt))
            .OrderBy(p => p.Name)
            .ToListAsync();
    }

    public Task<Product?> GetByIdAsync(int id) => db.Products.FindAsync(id).AsTask();

    public async Task<Product> CreateAsync(Product p)
    {
        p.CreatedAt = DateTime.UtcNow;
        db.Products.Add(p);
        await db.SaveChangesAsync();
        // Create inventory record
        db.Inventories.Add(new Inventory { ProductId = p.Id, CurrentStock = 0, LastUpdated = DateTime.UtcNow });
        await db.SaveChangesAsync();
        return p;
    }

    public async Task<Product?> UpdateAsync(int id, Product p)
    {
        var existing = await db.Products.FindAsync(id);
        if (existing is null) return null;
        p.Id = id; p.UpdatedAt = DateTime.UtcNow; p.CreatedAt = existing.CreatedAt;
        db.Entry(existing).CurrentValues.SetValues(p);
        await db.SaveChangesAsync(); return existing;
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var p = await db.Products.FindAsync(id);
        if (p is null) return false;
        db.Products.Remove(p); await db.SaveChangesAsync(); return true;
    }
}

public record ProductDto(int Id, string Name, string Category, string? Brand, string? Model, string? Sku,
    decimal BuyPrice, decimal SellPrice, int MinStock, int WarrantyMonths, string Status,
    string? Description, int CurrentStock, DateTime CreatedAt);

// ═══════════════════════════════════════════════════════════════════════════════
// SALE SERVICE
// ═══════════════════════════════════════════════════════════════════════════════
public interface ISaleService
{
    Task<List<SaleDto>> GetAllAsync();
    Task<Sale?> GetByIdAsync(int id);
    Task<Sale> CreateAsync(Sale s);
    Task<Sale?> UpdateAsync(int id, Sale s);
    Task<bool> DeleteAsync(int id);
}

public class SaleService(AppDbContext db) : ISaleService
{
    public async Task<List<SaleDto>> GetAllAsync()
    {
        return await db.Sales
            .Include(s => s.Customer)
            .Include(s => s.Product)
            .Select(s => new SaleDto(
                s.Id, s.InvoiceNumber, s.CustomerId, s.Customer.FullName,
                s.ProductId, s.Product.Name, s.Quantity, s.UnitPrice,
                s.Discount, s.TotalAmount, s.Profit, s.SaleDate,
                s.PaymentMethod, s.Status, s.Notes, s.CreatedAt))
            .OrderByDescending(s => s.SaleDate)
            .ToListAsync();
    }

    public Task<Sale?> GetByIdAsync(int id) => db.Sales.FindAsync(id).AsTask();

    public async Task<Sale> CreateAsync(Sale s)
    {
        // Calculate profit
        var product = await db.Products.FindAsync(s.ProductId);
        if (product is not null)
            s.Profit = (s.UnitPrice - product.BuyPrice) * s.Quantity - s.Discount;

        s.InvoiceNumber = $"INV-{DateTime.UtcNow:yyyyMMdd}-{new Random().Next(1000, 9999)}";
        s.CreatedAt = DateTime.UtcNow;
        db.Sales.Add(s);

        // Deduct from inventory
        var inv = await db.Inventories.FirstOrDefaultAsync(i => i.ProductId == s.ProductId);
        if (inv is not null && s.Status == "Completed")
        {
            inv.CurrentStock = Math.Max(0, inv.CurrentStock - s.Quantity);
            inv.LastUpdated  = DateTime.UtcNow;
        }

        await db.SaveChangesAsync();
        return s;
    }

    public async Task<Sale?> UpdateAsync(int id, Sale s)
    {
        var existing = await db.Sales.FindAsync(id);
        if (existing is null) return null;
        s.Id = id; s.UpdatedAt = DateTime.UtcNow; s.CreatedAt = existing.CreatedAt;
        s.InvoiceNumber = existing.InvoiceNumber;
        db.Entry(existing).CurrentValues.SetValues(s);
        await db.SaveChangesAsync(); return existing;
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var s = await db.Sales.FindAsync(id);
        if (s is null) return false;
        db.Sales.Remove(s); await db.SaveChangesAsync(); return true;
    }
}

public record SaleDto(int Id, string InvoiceNumber, int CustomerId, string CustomerName,
    int ProductId, string ProductName, int Quantity, decimal UnitPrice, decimal Discount,
    decimal TotalAmount, decimal Profit, DateTime SaleDate, string PaymentMethod,
    string Status, string? Notes, DateTime CreatedAt);

// ═══════════════════════════════════════════════════════════════════════════════
// PURCHASE SERVICE
// ═══════════════════════════════════════════════════════════════════════════════
public interface IPurchaseService
{
    Task<List<PurchaseDto>> GetAllAsync();
    Task<Purchase?> GetByIdAsync(int id);
    Task<Purchase> CreateAsync(Purchase p);
    Task<Purchase?> UpdateAsync(int id, Purchase p);
    Task<bool> DeleteAsync(int id);
}

public class PurchaseService(AppDbContext db) : IPurchaseService
{
    public async Task<List<PurchaseDto>> GetAllAsync()
    {
        return await db.Purchases
            .Include(p => p.Product)
            .Select(p => new PurchaseDto(
                p.Id, p.SupplierName, p.ProductId, p.Product.Name,
                p.Quantity, p.UnitCost, p.TotalCost, p.PurchaseDate,
                p.InvoiceNumber, p.Status, p.Notes, p.CreatedAt))
            .OrderByDescending(p => p.PurchaseDate)
            .ToListAsync();
    }

    public Task<Purchase?> GetByIdAsync(int id) => db.Purchases.FindAsync(id).AsTask();

    public async Task<Purchase> CreateAsync(Purchase p)
    {
        p.CreatedAt = DateTime.UtcNow;
        db.Purchases.Add(p);

        // Add to inventory if received
        if (p.Status == "Received")
        {
            var inv = await db.Inventories.FirstOrDefaultAsync(i => i.ProductId == p.ProductId);
            if (inv is not null) { inv.CurrentStock += p.Quantity; inv.LastUpdated = DateTime.UtcNow; }
        }

        await db.SaveChangesAsync();
        return p;
    }

    public async Task<Purchase?> UpdateAsync(int id, Purchase p)
    {
        var existing = await db.Purchases.FindAsync(id);
        if (existing is null) return null;
        p.Id = id; p.UpdatedAt = DateTime.UtcNow; p.CreatedAt = existing.CreatedAt;
        db.Entry(existing).CurrentValues.SetValues(p);
        await db.SaveChangesAsync(); return existing;
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var p = await db.Purchases.FindAsync(id);
        if (p is null) return false;
        db.Purchases.Remove(p); await db.SaveChangesAsync(); return true;
    }
}

public record PurchaseDto(int Id, string SupplierName, int ProductId, string ProductName,
    int Quantity, decimal UnitCost, decimal TotalCost, DateTime PurchaseDate,
    string? InvoiceNumber, string Status, string? Notes, DateTime CreatedAt);

// ═══════════════════════════════════════════════════════════════════════════════
// EXPENSE SERVICE
// ═══════════════════════════════════════════════════════════════════════════════
public interface IExpenseService
{
    Task<List<Expense>> GetAllAsync();
    Task<Expense?> GetByIdAsync(int id);
    Task<Expense> CreateAsync(Expense e);
    Task<Expense?> UpdateAsync(int id, Expense e);
    Task<bool> DeleteAsync(int id);
}

public class ExpenseService(AppDbContext db) : IExpenseService
{
    public Task<List<Expense>> GetAllAsync() => db.Expenses.OrderByDescending(e => e.ExpenseDate).ToListAsync();
    public Task<Expense?> GetByIdAsync(int id) => db.Expenses.FindAsync(id).AsTask();

    public async Task<Expense> CreateAsync(Expense e)
    {
        e.CreatedAt = DateTime.UtcNow;
        db.Expenses.Add(e); await db.SaveChangesAsync(); return e;
    }

    public async Task<Expense?> UpdateAsync(int id, Expense e)
    {
        var existing = await db.Expenses.FindAsync(id);
        if (existing is null) return null;
        e.Id = id; e.UpdatedAt = DateTime.UtcNow; e.CreatedAt = existing.CreatedAt;
        db.Entry(existing).CurrentValues.SetValues(e);
        await db.SaveChangesAsync(); return existing;
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var e = await db.Expenses.FindAsync(id);
        if (e is null) return false;
        db.Expenses.Remove(e); await db.SaveChangesAsync(); return true;
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// INVENTORY SERVICE
// ═══════════════════════════════════════════════════════════════════════════════
public interface IInventoryService
{
    Task<List<InventoryDto>> GetAllAsync();
    Task<InventoryDto?> GetByIdAsync(int id);
    Task<Inventory?> UpdateStockAsync(int id, int newStock, string? reason);
    Task<List<InventoryDto>> GetLowStockAsync();
}

public class InventoryService(AppDbContext db) : IInventoryService
{
    public async Task<List<InventoryDto>> GetAllAsync()
    {
        return await db.Inventories
            .Include(i => i.Product)
            .Select(i => new InventoryDto(
                i.Id, i.ProductId, i.Product.Name, i.Product.Category,
                i.CurrentStock, i.Product.MinStock,
                i.CurrentStock * i.Product.BuyPrice, i.LastUpdated))
            .OrderBy(i => i.ProductName)
            .ToListAsync();
    }

    public async Task<InventoryDto?> GetByIdAsync(int id)
    {
        var i = await db.Inventories.Include(x => x.Product).FirstOrDefaultAsync(x => x.Id == id);
        if (i is null) return null;
        return new InventoryDto(i.Id, i.ProductId, i.Product.Name, i.Product.Category,
            i.CurrentStock, i.Product.MinStock, i.CurrentStock * i.Product.BuyPrice, i.LastUpdated);
    }

    public async Task<Inventory?> UpdateStockAsync(int id, int newStock, string? reason)
    {
        var inv = await db.Inventories.FindAsync(id);
        if (inv is null) return null;
        inv.CurrentStock = newStock;
        inv.LastUpdated  = DateTime.UtcNow;
        await db.SaveChangesAsync();
        return inv;
    }

    public async Task<List<InventoryDto>> GetLowStockAsync()
    {
        return await db.Inventories
            .Include(i => i.Product)
            .Where(i => i.CurrentStock <= i.Product.MinStock)
            .Select(i => new InventoryDto(
                i.Id, i.ProductId, i.Product.Name, i.Product.Category,
                i.CurrentStock, i.Product.MinStock,
                i.CurrentStock * i.Product.BuyPrice, i.LastUpdated))
            .ToListAsync();
    }
}

public record InventoryDto(int Id, int ProductId, string ProductName, string Category,
    int CurrentStock, int MinStock, decimal StockValue, DateTime LastUpdated);
