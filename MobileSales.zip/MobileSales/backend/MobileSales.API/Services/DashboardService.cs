using Microsoft.EntityFrameworkCore;
using MobileSales.API.Data;

namespace MobileSales.API.Services;

public interface IDashboardService
{
    Task<DashboardStats> GetStatsAsync();
    Task<SalesChartData> GetSalesChartAsync();
    Task<TopProductsData> GetTopProductsAsync();
}

public class DashboardService(AppDbContext db) : IDashboardService
{
    public async Task<DashboardStats> GetStatsAsync()
    {
        var now   = DateTime.UtcNow;
        var month = new DateTime(now.Year, now.Month, 1);
        var prevMonth = month.AddMonths(-1);

        var totalSales    = await db.Sales.CountAsync();
        var revenue       = await db.Sales.Where(s => s.Status == "Completed").SumAsync(s => (decimal?)s.TotalAmount) ?? 0;
        var prevRevenue   = await db.Sales.Where(s => s.Status == "Completed" && s.SaleDate >= prevMonth && s.SaleDate < month).SumAsync(s => (decimal?)s.TotalAmount) ?? 0;
        var currRevenue   = await db.Sales.Where(s => s.Status == "Completed" && s.SaleDate >= month).SumAsync(s => (decimal?)s.TotalAmount) ?? 0;

        var totalCustomers = await db.Customers.CountAsync();
        var prevCustomers  = await db.Customers.CountAsync(c => c.CreatedAt < month);
        var currCustomers  = await db.Customers.CountAsync(c => c.CreatedAt >= month);

        var lowStockCount  = await db.Inventories.CountAsync(i => i.CurrentStock <= i.Product.MinStock);
        var totalProducts  = await db.Products.CountAsync();
        var totalEmployees = await db.Employees.CountAsync(e => e.Status == "Active");

        var monthlyPurchases = await db.Purchases.Where(p => p.PurchaseDate >= month).SumAsync(p => (decimal?)p.TotalCost) ?? 0;
        var monthlyExpenses  = await db.Expenses.Where(e => e.ExpenseDate >= month).SumAsync(e => (decimal?)e.Amount) ?? 0;

        var prevSalesCount = await db.Sales.CountAsync(s => s.SaleDate >= prevMonth && s.SaleDate < month);
        var currSalesCount = await db.Sales.CountAsync(s => s.SaleDate >= month);

        return new DashboardStats(
            totalSales, revenue, totalCustomers, lowStockCount,
            totalProducts, totalEmployees, monthlyPurchases, monthlyExpenses,
            CalcChange(prevSalesCount, currSalesCount),
            CalcChange(prevRevenue, currRevenue),
            CalcChange(prevCustomers, currCustomers));
    }

    public async Task<SalesChartData> GetSalesChartAsync()
    {
        var months = Enumerable.Range(0, 6)
            .Select(i => DateTime.UtcNow.AddMonths(-5 + i))
            .ToList();

        var labels = months.Select(m => m.ToString("MMM yyyy")).ToList();

        var salesValues = new List<decimal>();
        var purchaseValues = new List<decimal>();

        foreach (var m in months)
        {
            var start = new DateTime(m.Year, m.Month, 1);
            var end   = start.AddMonths(1);
            salesValues.Add(await db.Sales.Where(s => s.SaleDate >= start && s.SaleDate < end && s.Status == "Completed").SumAsync(s => (decimal?)s.TotalAmount) ?? 0);
            purchaseValues.Add(await db.Purchases.Where(p => p.PurchaseDate >= start && p.PurchaseDate < end).SumAsync(p => (decimal?)p.TotalCost) ?? 0);
        }

        return new SalesChartData(labels, salesValues, purchaseValues);
    }

    public async Task<TopProductsData> GetTopProductsAsync()
    {
        var top = await db.Sales
            .Where(s => s.Status == "Completed")
            .GroupBy(s => s.Product.Name)
            .Select(g => new { Name = g.Key, Total = g.Sum(s => s.TotalAmount) })
            .OrderByDescending(x => x.Total)
            .Take(6)
            .ToListAsync();

        return new TopProductsData(top.Select(x => x.Name).ToList(), top.Select(x => x.Total).ToList());
    }

    private static decimal CalcChange(decimal prev, decimal curr) =>
        prev == 0 ? 0 : Math.Round((curr - prev) / prev * 100, 1);
}

public record DashboardStats(
    int TotalSales, decimal Revenue, int TotalCustomers, int LowStockCount,
    int TotalProducts, int TotalEmployees, decimal MonthlyPurchases, decimal MonthlyExpenses,
    decimal SalesChangePercent, decimal RevenueChangePercent, decimal CustomersChangePercent);

public record SalesChartData(List<string> Labels, List<decimal> Values, List<decimal> PurchaseValues);
public record TopProductsData(List<string> Labels, List<decimal> Values);
