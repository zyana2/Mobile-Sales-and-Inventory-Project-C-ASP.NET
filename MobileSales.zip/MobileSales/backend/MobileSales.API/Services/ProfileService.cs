using Microsoft.EntityFrameworkCore;
using MobileSales.API.Data;
using MobileSales.API.Models;

namespace MobileSales.API.Services;

public interface IProfileService
{
    Task<ProfileDto?> GetByUserIdAsync(int userId);
    Task<UserProfile?> UpdateAsync(int userId, UpdateProfileRequest req);
    Task<Education> AddEducationAsync(int userId, Education edu);
    Task<Education?> UpdateEducationAsync(int id, int userId, Education edu);
    Task<bool> DeleteEducationAsync(int id, int userId);
    Task<Experience> AddExperienceAsync(int userId, Experience exp);
    Task<Experience?> UpdateExperienceAsync(int id, int userId, Experience exp);
    Task<bool> DeleteExperienceAsync(int id, int userId);
}

public class ProfileService(AppDbContext db) : IProfileService
{
    public async Task<ProfileDto?> GetByUserIdAsync(int userId)
    {
        var user = await db.Users.FindAsync(userId);
        if (user is null) return null;

        var profile = await db.UserProfiles
            .Include(p => p.Educations)
            .Include(p => p.Experiences)
            .Include(p => p.Courses)
            .Include(p => p.Projects)
            .FirstOrDefaultAsync(p => p.UserId == userId);

        return new ProfileDto(
            user.Id, user.FullName, user.Email, user.Role, user.Status,
            profile?.Phone, profile?.Cnic, profile?.DateOfBirth,
            profile?.City, profile?.Address, profile?.Bio,
            profile?.Educations.ToList() ?? [],
            profile?.Experiences.ToList() ?? [],
            profile?.Courses.ToList() ?? [],
            profile?.Projects.ToList() ?? []);
    }

    public async Task<UserProfile?> UpdateAsync(int userId, UpdateProfileRequest req)
    {
        var profile = await db.UserProfiles.FirstOrDefaultAsync(p => p.UserId == userId);
        if (profile is null) return null;

        profile.Phone       = req.Phone;
        profile.Cnic        = req.Cnic;
        profile.DateOfBirth = req.DateOfBirth;
        profile.City        = req.City;
        profile.Address     = req.Address;
        profile.Bio         = req.Bio;
        profile.UpdatedAt   = DateTime.UtcNow;

        // Update user's full name and email
        var user = await db.Users.FindAsync(userId);
        if (user is not null)
        {
            user.FullName  = req.FullName ?? user.FullName;
            user.Email     = req.Email ?? user.Email;
            user.UpdatedAt = DateTime.UtcNow;
        }

        await db.SaveChangesAsync();
        return profile;
    }

    public async Task<Education> AddEducationAsync(int userId, Education edu)
    {
        var profile = await db.UserProfiles.FirstOrDefaultAsync(p => p.UserId == userId)
            ?? throw new InvalidOperationException("Profile not found.");
        edu.UserProfileId = profile.Id;
        db.Educations.Add(edu);
        await db.SaveChangesAsync();
        return edu;
    }

    public async Task<Education?> UpdateEducationAsync(int id, int userId, Education edu)
    {
        var profile = await db.UserProfiles.FirstOrDefaultAsync(p => p.UserId == userId);
        var existing = await db.Educations.FirstOrDefaultAsync(e => e.Id == id && e.UserProfileId == profile!.Id);
        if (existing is null) return null;
        edu.Id = id; edu.UserProfileId = existing.UserProfileId;
        db.Entry(existing).CurrentValues.SetValues(edu);
        await db.SaveChangesAsync();
        return existing;
    }

    public async Task<bool> DeleteEducationAsync(int id, int userId)
    {
        var profile = await db.UserProfiles.FirstOrDefaultAsync(p => p.UserId == userId);
        var edu = await db.Educations.FirstOrDefaultAsync(e => e.Id == id && e.UserProfileId == profile!.Id);
        if (edu is null) return false;
        db.Educations.Remove(edu);
        await db.SaveChangesAsync();
        return true;
    }

    public async Task<Experience> AddExperienceAsync(int userId, Experience exp)
    {
        var profile = await db.UserProfiles.FirstOrDefaultAsync(p => p.UserId == userId)
            ?? throw new InvalidOperationException("Profile not found.");
        exp.UserProfileId = profile.Id;
        db.Experiences.Add(exp);
        await db.SaveChangesAsync();
        return exp;
    }

    public async Task<Experience?> UpdateExperienceAsync(int id, int userId, Experience exp)
    {
        var profile = await db.UserProfiles.FirstOrDefaultAsync(p => p.UserId == userId);
        var existing = await db.Experiences.FirstOrDefaultAsync(e => e.Id == id && e.UserProfileId == profile!.Id);
        if (existing is null) return null;
        exp.Id = id; exp.UserProfileId = existing.UserProfileId;
        db.Entry(existing).CurrentValues.SetValues(exp);
        await db.SaveChangesAsync();
        return existing;
    }

    public async Task<bool> DeleteExperienceAsync(int id, int userId)
    {
        var profile = await db.UserProfiles.FirstOrDefaultAsync(p => p.UserId == userId);
        var exp = await db.Experiences.FirstOrDefaultAsync(e => e.Id == id && e.UserProfileId == profile!.Id);
        if (exp is null) return false;
        db.Experiences.Remove(exp);
        await db.SaveChangesAsync();
        return true;
    }
}

public record ProfileDto(
    int Id, string FullName, string? Email, string Role, string Status,
    string? Phone, string? Cnic, DateTime? DateOfBirth, string? City, string? Address, string? Bio,
    List<Education> Education, List<Experience> Experience, List<Course> Courses, List<Project> Projects);

public record UpdateProfileRequest(
    string? FullName, string? Email, string? Phone, string? Cnic,
    DateTime? DateOfBirth, string? City, string? Address, string? Bio);
