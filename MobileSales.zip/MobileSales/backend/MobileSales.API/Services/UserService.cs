using Microsoft.EntityFrameworkCore;
using MobileSales.API.Data;
using MobileSales.API.Models;

namespace MobileSales.API.Services;

public interface IUserService
{
    Task<List<UserListDto>> GetAllAsync();
    Task<UserListDto?> GetByIdAsync(int id);
    Task<UserListDto> CreateAsync(CreateUserRequest req);
    Task<UserListDto?> UpdateAsync(int id, UpdateUserRequest req);
    Task<bool> DeleteAsync(int id);
    Task<string?> ResetPasswordAsync(int id);
}

public class UserService(AppDbContext db) : IUserService
{
    public async Task<List<UserListDto>> GetAllAsync() =>
        await db.Users.Select(u => MapToDto(u)).ToListAsync();

    public async Task<UserListDto?> GetByIdAsync(int id)
    {
        var u = await db.Users.FindAsync(id);
        return u is null ? null : MapToDto(u);
    }

    public async Task<UserListDto> CreateAsync(CreateUserRequest req)
    {
        var user = new User
        {
            Username           = req.Username,
            PasswordHash       = BCrypt.Net.BCrypt.HashPassword(req.Password),
            FullName           = req.FullName,
            Email              = req.Email,
            Role               = req.Role,
            Status             = req.Status,
            MustChangePassword = true,
            CreatedAt          = DateTime.UtcNow,
        };
        db.Users.Add(user);
        await db.SaveChangesAsync();

        // Create empty profile
        db.UserProfiles.Add(new UserProfile { UserId = user.Id, CreatedAt = DateTime.UtcNow });
        await db.SaveChangesAsync();

        return MapToDto(user);
    }

    public async Task<UserListDto?> UpdateAsync(int id, UpdateUserRequest req)
    {
        var user = await db.Users.FindAsync(id);
        if (user is null) return null;

        user.FullName  = req.FullName;
        user.Email     = req.Email;
        user.Role      = req.Role;
        user.Status    = req.Status;
        user.UpdatedAt = DateTime.UtcNow;
        await db.SaveChangesAsync();
        return MapToDto(user);
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var user = await db.Users.FindAsync(id);
        if (user is null) return false;
        db.Users.Remove(user);
        await db.SaveChangesAsync();
        return true;
    }

    public async Task<string?> ResetPasswordAsync(int id)
    {
        var user = await db.Users.FindAsync(id);
        if (user is null) return null;

        var newPwd = GeneratePassword();
        user.PasswordHash       = BCrypt.Net.BCrypt.HashPassword(newPwd);
        user.MustChangePassword = true;
        user.UpdatedAt          = DateTime.UtcNow;
        await db.SaveChangesAsync();
        return newPwd;
    }

    private static string GeneratePassword()
    {
        const string chars = "ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789@#$";
        var rng = new Random();
        return new string(Enumerable.Range(0, 10).Select(_ => chars[rng.Next(chars.Length)]).ToArray());
    }

    private static UserListDto MapToDto(User u) => new(
        u.Id, u.Username, u.FullName, u.Email, u.Role, u.Status, u.MustChangePassword, u.LastLogin, u.CreatedAt);
}

public record CreateUserRequest(string Username, string Password, string FullName, string? Email, string Role, string Status);
public record UpdateUserRequest(string FullName, string? Email, string Role, string Status);
public record UserListDto(int Id, string Username, string FullName, string? Email, string Role, string Status, bool MustChangePassword, DateTime? LastLogin, DateTime CreatedAt);
