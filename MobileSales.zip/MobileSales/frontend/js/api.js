/* ===================================================
   api.js  –  Central API communication layer
   All fetch calls go through here.
   Base URL points to the C# Web API backend.
=================================================== */

const API_BASE = 'https://localhost:7001/api'; // Change to your deployed URL

const Api = {

  /* ---- Auth helpers ---- */
  getToken() {
    return localStorage.getItem('mp_token') || sessionStorage.getItem('mp_token');
  },

  getUser() {
    const u = localStorage.getItem('mp_user') || sessionStorage.getItem('mp_user');
    return u ? JSON.parse(u) : null;
  },

  setSession(token, user, remember) {
    const store = remember ? localStorage : sessionStorage;
    store.setItem('mp_token', token);
    store.setItem('mp_user', JSON.stringify(user));
  },

  clearSession() {
    localStorage.removeItem('mp_token');
    localStorage.removeItem('mp_user');
    sessionStorage.removeItem('mp_token');
    sessionStorage.removeItem('mp_user');
  },

  isLoggedIn() {
    return !!this.getToken();
  },

  /* ---- Core request ---- */
  async request(method, endpoint, body = null, auth = true) {
    const headers = { 'Content-Type': 'application/json' };
    if (auth) {
      const token = this.getToken();
      if (!token) { this.redirectToLogin(); return; }
      headers['Authorization'] = `Bearer ${token}`;
    }

    const options = { method, headers };
    if (body) options.body = JSON.stringify(body);

    try {
      const res = await fetch(`${API_BASE}${endpoint}`, options);

      if (res.status === 401) { this.clearSession(); this.redirectToLogin(); return; }

      const data = res.status === 204 ? null : await res.json();

      if (!res.ok) {
        throw { status: res.status, message: data?.message || data?.title || 'Request failed' };
      }
      return data;
    } catch (err) {
      if (err.status) throw err;
      throw { status: 0, message: 'Network error. Please check your connection.' };
    }
  },

  get(endpoint)         { return this.request('GET',    endpoint); },
  post(endpoint, body)  { return this.request('POST',   endpoint, body); },
  put(endpoint, body)   { return this.request('PUT',    endpoint, body); },
  patch(endpoint, body) { return this.request('PATCH',  endpoint, body); },
  delete(endpoint)      { return this.request('DELETE', endpoint); },

  redirectToLogin() { window.location.href = '/index.html'; },

  /* ---- Auth endpoints ---- */
  auth: {
    login: (creds)           => Api.request('POST', '/auth/login',           creds, false),
    changePassword: (payload) => Api.request('POST', '/auth/change-password', payload),
    logout: ()               => Api.request('POST', '/auth/logout'),
  },

  /* ---- Users ---- */
  users: {
    getAll:   ()       => Api.get('/users'),
    getById:  (id)     => Api.get(`/users/${id}`),
    create:   (data)   => Api.post('/users', data),
    update:   (id, d)  => Api.put(`/users/${id}`, d),
    delete:   (id)     => Api.delete(`/users/${id}`),
    resetPwd: (id)     => Api.post(`/users/${id}/reset-password`),
  },

  /* ---- Profile ---- */
  profile: {
    get:              ()     => Api.get('/profile'),
    update:           (d)    => Api.put('/profile', d),
    addEducation:     (d)    => Api.post('/profile/education', d),
    updateEducation:  (id,d) => Api.put(`/profile/education/${id}`, d),
    deleteEducation:  (id)   => Api.delete(`/profile/education/${id}`),
    addExperience:    (d)    => Api.post('/profile/experience', d),
    updateExperience: (id,d) => Api.put(`/profile/experience/${id}`, d),
    deleteExperience: (id)   => Api.delete(`/profile/experience/${id}`),
  },

  /* ---- Employees ---- */
  employees: {
    getAll:  ()      => Api.get('/employees'),
    getById: (id)    => Api.get(`/employees/${id}`),
    create:  (d)     => Api.post('/employees', d),
    update:  (id, d) => Api.put(`/employees/${id}`, d),
    delete:  (id)    => Api.delete(`/employees/${id}`),
  },

  /* ---- Customers ---- */
  customers: {
    getAll:  ()      => Api.get('/customers'),
    getById: (id)    => Api.get(`/customers/${id}`),
    create:  (d)     => Api.post('/customers', d),
    update:  (id, d) => Api.put(`/customers/${id}`, d),
    delete:  (id)    => Api.delete(`/customers/${id}`),
  },

  /* ---- Products ---- */
  products: {
    getAll:  ()      => Api.get('/products'),
    getById: (id)    => Api.get(`/products/${id}`),
    create:  (d)     => Api.post('/products', d),
    update:  (id, d) => Api.put(`/products/${id}`, d),
    delete:  (id)    => Api.delete(`/products/${id}`),
  },

  /* ---- Sales ---- */
  sales: {
    getAll:  ()      => Api.get('/sales'),
    getById: (id)    => Api.get(`/sales/${id}`),
    create:  (d)     => Api.post('/sales', d),
    update:  (id, d) => Api.put(`/sales/${id}`, d),
    delete:  (id)    => Api.delete(`/sales/${id}`),
  },

  /* ---- Purchases ---- */
  purchases: {
    getAll:  ()      => Api.get('/purchases'),
    getById: (id)    => Api.get(`/purchases/${id}`),
    create:  (d)     => Api.post('/purchases', d),
    update:  (id, d) => Api.put(`/purchases/${id}`, d),
    delete:  (id)    => Api.delete(`/purchases/${id}`),
  },

  /* ---- Expenses ---- */
  expenses: {
    getAll:  ()      => Api.get('/expenses'),
    getById: (id)    => Api.get(`/expenses/${id}`),
    create:  (d)     => Api.post('/expenses', d),
    update:  (id, d) => Api.put(`/expenses/${id}`, d),
    delete:  (id)    => Api.delete(`/expenses/${id}`),
  },

  /* ---- Inventory ---- */
  inventory: {
    getAll:      ()      => Api.get('/inventory'),
    getById:     (id)    => Api.get(`/inventory/${id}`),
    update:      (id, d) => Api.put(`/inventory/${id}`, d),
    getLowStock: ()      => Api.get('/inventory/low-stock'),
  },

  /* ---- Dashboard ---- */
  dashboard: {
    getStats:   () => Api.get('/dashboard/stats'),
    getSales:   () => Api.get('/dashboard/sales-chart'),
    getTopProd: () => Api.get('/dashboard/top-products'),
  },
};
