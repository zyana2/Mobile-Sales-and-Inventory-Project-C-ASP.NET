/* ===================================================
   app.js  –  Shared layout logic (sidebar, topbar,
              auth guard, navigation)
   Include this on every page AFTER api.js
=================================================== */

const App = {

  /* ---- Auth guard ---- */
  requireAuth(allowedRoles = []) {
    if (!Api.isLoggedIn()) {
      Api.redirectToLogin();
      return false;
    }
    const user = Api.getUser();
    if (allowedRoles.length && !allowedRoles.includes(user.role)) {
      window.location.href = 'dashboard.html';
      return false;
    }
    return true;
  },

  /* ---- Render layout ---- */
  init(pageTitle = 'Dashboard', activeMenu = 'dashboard') {
    if (!this.requireAuth()) return;

    const user = Api.getUser();

    // Inject sidebar + topbar HTML
    document.body.insertAdjacentHTML('afterbegin', this.buildLayout(user, pageTitle, activeMenu));

    // Set active nav link
    document.querySelectorAll('.nav-link-custom').forEach(link => {
      if (link.dataset.menu === activeMenu) link.classList.add('active');
    });

    // Sidebar toggle
    const sidebar     = document.getElementById('sidebar');
    const topbar      = document.getElementById('topbar');
    const mainContent = document.getElementById('mainContent');
    const toggleBtn   = document.getElementById('sidebarToggle');

    toggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('collapsed');
      topbar.classList.toggle('collapsed');
      mainContent.classList.toggle('collapsed');
    });

    // Mobile overlay
    document.getElementById('sidebarOverlay')?.addEventListener('click', () => {
      sidebar.classList.remove('mobile-open');
    });

    // Submenu toggles
    document.querySelectorAll('.has-submenu > .nav-link-custom').forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        link.closest('.has-submenu').classList.toggle('open');
      });
    });

    // Logout
    document.getElementById('logoutBtn')?.addEventListener('click', async () => {
      try { await Api.auth.logout(); } catch (_) {}
      Api.clearSession();
      Api.redirectToLogin();
    });

    // User avatar initials
    const avatarEl = document.getElementById('userAvatar');
    if (avatarEl) {
      avatarEl.textContent = this.getInitials(user.fullName || user.username);
    }

    document.getElementById('topbarUserName').textContent = user.fullName || user.username;
    document.getElementById('topbarUserRole').textContent = user.role;
  },

  getInitials(name) {
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  },

  /* ---- Build sidebar HTML ---- */
  buildLayout(user, pageTitle, activeMenu) {
    const role = user.role;
    const isAdmin   = role === 'Admin';
    const isManager = role === 'Admin' || role === 'Manager';

    return `
    <!-- Sidebar Overlay (mobile) -->
    <div id="sidebarOverlay" class="d-md-none position-fixed top-0 start-0 w-100 h-100" style="background:rgba(0,0,0,0.5);z-index:999;display:none!important;"></div>

    <!-- SIDEBAR -->
    <nav id="sidebar">
      <a href="dashboard.html" class="sidebar-brand">
        <div class="brand-icon"><i class="bi bi-phone-fill"></i></div>
        <span class="brand-text">MobilePro</span>
      </a>

      <ul class="sidebar-nav list-unstyled mb-0">

        <li class="sidebar-section-title">Main</li>

        <li class="nav-item-custom">
          <a href="dashboard.html" class="nav-link-custom" data-menu="dashboard">
            <i class="bi bi-speedometer2"></i>
            <span class="menu-text">Dashboard</span>
          </a>
        </li>

        <li class="sidebar-section-title">Operations</li>

        <li class="nav-item-custom">
          <a href="sales.html" class="nav-link-custom" data-menu="sales">
            <i class="bi bi-cart-check-fill"></i>
            <span class="menu-text">Sales</span>
          </a>
        </li>

        <li class="nav-item-custom">
          <a href="purchases.html" class="nav-link-custom" data-menu="purchases">
            <i class="bi bi-bag-plus-fill"></i>
            <span class="menu-text">Purchases</span>
          </a>
        </li>

        <li class="nav-item-custom">
          <a href="expenses.html" class="nav-link-custom" data-menu="expenses">
            <i class="bi bi-cash-stack"></i>
            <span class="menu-text">Expenses</span>
          </a>
        </li>

        <li class="sidebar-section-title">Inventory</li>

        <li class="nav-item-custom">
          <a href="products.html" class="nav-link-custom" data-menu="products">
            <i class="bi bi-phone"></i>
            <span class="menu-text">Products</span>
          </a>
        </li>

        <li class="nav-item-custom">
          <a href="inventory.html" class="nav-link-custom" data-menu="inventory">
            <i class="bi bi-boxes"></i>
            <span class="menu-text">Inventory / Stock</span>
          </a>
        </li>

        <li class="sidebar-section-title">People</li>

        <li class="nav-item-custom">
          <a href="customers.html" class="nav-link-custom" data-menu="customers">
            <i class="bi bi-people-fill"></i>
            <span class="menu-text">Customers</span>
          </a>
        </li>

        ${isManager ? `
        <li class="nav-item-custom">
          <a href="employees.html" class="nav-link-custom" data-menu="employees">
            <i class="bi bi-person-badge-fill"></i>
            <span class="menu-text">Employees</span>
          </a>
        </li>` : ''}

        ${isAdmin ? `
        <li class="sidebar-section-title">Administration</li>
        <li class="nav-item-custom">
          <a href="users.html" class="nav-link-custom" data-menu="users">
            <i class="bi bi-shield-lock-fill"></i>
            <span class="menu-text">User Management</span>
          </a>
        </li>` : ''}

        <li class="sidebar-section-title">Account</li>

        <li class="nav-item-custom">
          <a href="profile.html" class="nav-link-custom" data-menu="profile">
            <i class="bi bi-person-circle"></i>
            <span class="menu-text">My Profile</span>
          </a>
        </li>

        <li class="nav-item-custom">
          <a href="#" class="nav-link-custom text-danger" id="logoutBtn">
            <i class="bi bi-box-arrow-left"></i>
            <span class="menu-text">Logout</span>
          </a>
        </li>

      </ul>
    </nav>

    <!-- TOPBAR -->
    <header id="topbar">
      <div class="topbar-left">
        <button id="sidebarToggle" class="topbar-icon-btn">
          <i class="bi bi-list fs-5"></i>
        </button>
        <h6 class="page-title">${pageTitle}</h6>
      </div>
      <div class="topbar-right">
        <button class="topbar-icon-btn" title="Notifications">
          <i class="bi bi-bell-fill"></i>
          <span class="notif-badge">3</span>
        </button>
        <div class="dropdown">
          <div class="d-flex align-items-center gap-2" style="cursor:pointer" data-bs-toggle="dropdown">
            <div class="user-avatar" id="userAvatar">AD</div>
            <div class="d-none d-md-block">
              <div class="fw-semibold small" id="topbarUserName">Admin</div>
              <div class="text-muted" style="font-size:0.7rem" id="topbarUserRole">Role</div>
            </div>
          </div>
          <ul class="dropdown-menu dropdown-menu-end shadow">
            <li><a class="dropdown-item" href="profile.html"><i class="bi bi-person me-2"></i>My Profile</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" href="#" id="logoutBtn2"><i class="bi bi-box-arrow-left me-2"></i>Logout</a></li>
          </ul>
        </div>
      </div>
    </header>
    `;
  },

  /* ---- Toast notifications ---- */
  toast(message, type = 'success') {
    const id = 'toast_' + Date.now();
    const icons = { success: 'check-circle-fill', danger: 'x-circle-fill', warning: 'exclamation-triangle-fill', info: 'info-circle-fill' };
    const html = `
      <div id="${id}" class="toast align-items-center text-bg-${type} border-0" role="alert" aria-live="assertive">
        <div class="d-flex">
          <div class="toast-body">
            <i class="bi bi-${icons[type] || 'info-circle-fill'} me-2"></i>${message}
          </div>
          <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
      </div>`;

    let container = document.getElementById('toastContainer');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toastContainer';
      container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
      container.style.zIndex = '9999';
      document.body.appendChild(container);
    }

    container.insertAdjacentHTML('beforeend', html);
    const toastEl = document.getElementById(id);
    const bsToast = new bootstrap.Toast(toastEl, { delay: 3500 });
    bsToast.show();
    toastEl.addEventListener('hidden.bs.toast', () => toastEl.remove());
  },

  /* ---- Confirm dialog ---- */
  confirm(message, onConfirm) {
    const id = 'confirmModal_' + Date.now();
    const html = `
      <div class="modal fade" id="${id}" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-sm">
          <div class="modal-content">
            <div class="modal-body text-center p-4">
              <i class="bi bi-exclamation-triangle-fill text-warning fs-1 mb-3 d-block"></i>
              <p class="mb-0">${message}</p>
            </div>
            <div class="modal-footer justify-content-center border-0 pt-0">
              <button class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
              <button class="btn btn-danger btn-sm" id="${id}_confirm">Delete</button>
            </div>
          </div>
        </div>
      </div>`;
    document.body.insertAdjacentHTML('beforeend', html);
    const modal = new bootstrap.Modal(document.getElementById(id));
    modal.show();
    document.getElementById(`${id}_confirm`).addEventListener('click', () => {
      modal.hide();
      onConfirm();
    });
    document.getElementById(id).addEventListener('hidden.bs.modal', () => {
      document.getElementById(id).remove();
    });
  },

  /* ---- Format helpers ---- */
  formatCurrency(val) {
    return new Intl.NumberFormat('en-PK', { style: 'currency', currency: 'PKR', maximumFractionDigits: 0 }).format(val);
  },

  formatDate(dateStr) {
    if (!dateStr) return '—';
    return new Date(dateStr).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  },

  /* ---- Table search ---- */
  initTableSearch(inputId, tableId) {
    document.getElementById(inputId)?.addEventListener('input', function () {
      const q = this.value.toLowerCase();
      document.querySelectorAll(`#${tableId} tbody tr`).forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
      });
    });
  },
};
