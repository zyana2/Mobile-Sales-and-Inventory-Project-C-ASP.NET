/* ===== CUSTOMERS PAGE ===== */
let customersData = [];
const modal = () => bootstrap.Modal.getOrCreateInstance(document.getElementById('customerModal'));

document.addEventListener('DOMContentLoaded', async () => {
  App.init('Customers', 'customers');
  App.initTableSearch('searchInput', 'customersTable');
  await loadCustomers();

  document.getElementById('saveCustomerBtn').addEventListener('click', saveCustomer);
});

async function loadCustomers() {
  const tbody = document.getElementById('customersBody');
  try {
    customersData = await Api.customers.getAll();
    renderTable(customersData);
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="8" class="text-center text-danger py-4">${err.message}</td></tr>`;
  }
}

function renderTable(data) {
  const tbody = document.getElementById('customersBody');
  if (!data.length) {
    tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted py-4">No customers found.</td></tr>';
    return;
  }
  tbody.innerHTML = data.map((c, i) => `
    <tr>
      <td>${i + 1}</td>
      <td>
        <div class="fw-semibold">${c.fullName}</div>
        <div class="text-muted small">${c.cnic || ''}</div>
      </td>
      <td>${c.phone}</td>
      <td>${c.email || '—'}</td>
      <td>${c.city || '—'}</td>
      <td class="fw-semibold text-success">${App.formatCurrency(c.totalPurchases || 0)}</td>
      <td>${App.formatDate(c.createdAt)}</td>
      <td>
        <button class="btn btn-sm btn-outline-primary me-1" onclick="editCustomer(${c.id})" title="Edit">
          <i class="bi bi-pencil-fill"></i>
        </button>
        <button class="btn btn-sm btn-outline-danger" onclick="deleteCustomer(${c.id}, '${c.fullName}')" title="Delete">
          <i class="bi bi-trash-fill"></i>
        </button>
      </td>
    </tr>`).join('');
}

function openAddModal() {
  document.getElementById('customerModalTitle').textContent = 'Add Customer';
  document.getElementById('customerForm').reset();
  document.getElementById('customerForm').classList.remove('was-validated');
  document.getElementById('customerId').value = '';
  document.getElementById('modalAlert').classList.add('d-none');
}

function editCustomer(id) {
  const c = customersData.find(x => x.id === id);
  if (!c) return;
  document.getElementById('customerModalTitle').textContent = 'Edit Customer';
  document.getElementById('customerId').value  = c.id;
  document.getElementById('custName').value    = c.fullName;
  document.getElementById('custPhone').value   = c.phone;
  document.getElementById('custEmail').value   = c.email || '';
  document.getElementById('custCnic').value    = c.cnic || '';
  document.getElementById('custCity').value    = c.city || '';
  document.getElementById('custAddress').value = c.address || '';
  document.getElementById('custNotes').value   = c.notes || '';
  document.getElementById('modalAlert').classList.add('d-none');
  document.getElementById('customerForm').classList.remove('was-validated');
  modal().show();
}

async function saveCustomer() {
  const form = document.getElementById('customerForm');
  form.classList.add('was-validated');
  if (!form.checkValidity()) return;

  const id = document.getElementById('customerId').value;
  const payload = {
    fullName: document.getElementById('custName').value.trim(),
    phone:    document.getElementById('custPhone').value.trim(),
    email:    document.getElementById('custEmail').value.trim(),
    cnic:     document.getElementById('custCnic').value.trim(),
    city:     document.getElementById('custCity').value.trim(),
    address:  document.getElementById('custAddress').value.trim(),
    notes:    document.getElementById('custNotes').value.trim(),
  };

  const btn = document.getElementById('saveCustomerBtn');
  const spinner = document.getElementById('saveSpinner');
  btn.disabled = true;
  spinner.classList.remove('d-none');

  try {
    if (id) {
      await Api.customers.update(id, payload);
      App.toast('Customer updated successfully.', 'success');
    } else {
      await Api.customers.create(payload);
      App.toast('Customer added successfully.', 'success');
    }
    modal().hide();
    await loadCustomers();
  } catch (err) {
    const alertBox = document.getElementById('modalAlert');
    alertBox.className = 'alert alert-danger';
    alertBox.textContent = err.message;
    alertBox.classList.remove('d-none');
  } finally {
    btn.disabled = false;
    spinner.classList.add('d-none');
  }
}

function deleteCustomer(id, name) {
  App.confirm(`Delete customer "<strong>${name}</strong>"? This cannot be undone.`, async () => {
    try {
      await Api.customers.delete(id);
      App.toast('Customer deleted.', 'success');
      await loadCustomers();
    } catch (err) {
      App.toast(err.message, 'danger');
    }
  });
}
