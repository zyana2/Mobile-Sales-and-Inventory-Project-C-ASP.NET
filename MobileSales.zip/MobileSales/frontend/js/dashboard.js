/* ===== DASHBOARD PAGE ===== */
document.addEventListener('DOMContentLoaded', async () => {
  App.init('Dashboard', 'dashboard');

  // Date display
  document.getElementById('dashDate').textContent =
    new Date().toLocaleDateString('en-GB', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

  await loadStats();
  await loadCharts();
  await loadRecentSales();
  await loadLowStock();
});

async function loadStats() {
  try {
    const stats = await Api.dashboard.getStats();
    document.getElementById('statTotalSales').textContent   = stats.totalSales ?? 0;
    document.getElementById('statRevenue').textContent      = App.formatCurrency(stats.revenue ?? 0);
    document.getElementById('statCustomers').textContent    = stats.totalCustomers ?? 0;
    document.getElementById('statLowStock').textContent     = stats.lowStockCount ?? 0;
    document.getElementById('statProducts').textContent     = stats.totalProducts ?? 0;
    document.getElementById('statEmployees').textContent    = stats.totalEmployees ?? 0;
    document.getElementById('statPurchases').textContent    = App.formatCurrency(stats.monthlyPurchases ?? 0);
    document.getElementById('statExpenses').textContent     = App.formatCurrency(stats.monthlyExpenses ?? 0);
    document.getElementById('statSalesChange').textContent  = (stats.salesChangePercent ?? 0) + '% this month';
    document.getElementById('statRevenueChange').textContent= (stats.revenueChangePercent ?? 0) + '% this month';
    document.getElementById('statCustomersChange').textContent = (stats.customersChangePercent ?? 0) + '% this month';
  } catch (err) {
    console.error('Stats error:', err);
  }
}

async function loadCharts() {
  try {
    const salesData = await Api.dashboard.getSales();
    const topProds  = await Api.dashboard.getTopProd();

    // Sales bar chart
    new Chart(document.getElementById('salesChart'), {
      type: 'bar',
      data: {
        labels: salesData.labels,
        datasets: [{
          label: 'Sales (PKR)',
          data: salesData.values,
          backgroundColor: 'rgba(13,110,253,0.7)',
          borderRadius: 6,
        }, {
          label: 'Purchases (PKR)',
          data: salesData.purchaseValues,
          backgroundColor: 'rgba(25,135,84,0.5)',
          borderRadius: 6,
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { position: 'top' } },
        scales: { y: { beginAtZero: true, ticks: { callback: v => 'PKR ' + v.toLocaleString() } } }
      }
    });

    // Top products doughnut
    new Chart(document.getElementById('topProductsChart'), {
      type: 'doughnut',
      data: {
        labels: topProds.labels,
        datasets: [{
          data: topProds.values,
          backgroundColor: ['#0d6efd','#198754','#ffc107','#dc3545','#0dcaf0','#6f42c1'],
          borderWidth: 2,
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { position: 'bottom', labels: { font: { size: 11 } } } }
      }
    });
  } catch (err) {
    console.error('Chart error:', err);
  }
}

async function loadRecentSales() {
  const tbody = document.getElementById('recentSalesBody');
  try {
    const sales = await Api.sales.getAll();
    const recent = sales.slice(0, 8);
    if (!recent.length) {
      tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted py-4">No sales yet.</td></tr>';
      return;
    }
    tbody.innerHTML = recent.map((s, i) => `
      <tr>
        <td>${i + 1}</td>
        <td>${s.customerName}</td>
        <td>${s.productName}</td>
        <td class="fw-semibold">${App.formatCurrency(s.totalAmount)}</td>
        <td>${App.formatDate(s.saleDate)}</td>
        <td><span class="badge badge-status ${s.status === 'Completed' ? 'bg-success' : 'bg-warning text-dark'}">${s.status}</span></td>
      </tr>`).join('');
  } catch (err) {
    tbody.innerHTML = '<tr><td colspan="6" class="text-center text-danger py-4">Failed to load.</td></tr>';
  }
}

async function loadLowStock() {
  const tbody = document.getElementById('lowStockBody');
  try {
    const items = await Api.inventory.getLowStock();
    if (!items.length) {
      tbody.innerHTML = '<tr><td colspan="3" class="text-center text-success py-4"><i class="bi bi-check-circle me-1"></i>All stock levels OK</td></tr>';
      return;
    }
    tbody.innerHTML = items.map(item => `
      <tr>
        <td>${item.productName}</td>
        <td><span class="badge bg-danger">${item.currentStock}</span></td>
        <td class="text-muted">${item.minStock}</td>
      </tr>`).join('');
  } catch (err) {
    tbody.innerHTML = '<tr><td colspan="3" class="text-center text-danger py-4">Failed to load.</td></tr>';
  }
}
