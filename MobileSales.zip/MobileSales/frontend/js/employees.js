/* ===== EMPLOYEES PAGE ===== */
let empData = [];
const modal = () => bootstrap.Modal.getOrCreateInstance(document.getElementById('empModal'));

document.addEventListener('DOMContentLoaded', async () => {
  App.init('Employees', 'employees');
  App.initTableSearch('searchInput', 'empTable');
  await loadEmployees();
  document.getElementById('saveEmpBtn').addEventListener('click', saveEmployee);
});

async function loadEmployees() {
  const tbody = document.getElementById('empBody');
  try {
    empData = await Api.employees.getAll();
    if (!empData.length) {
      tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted py-4">No employees found.</td></tr>';
      return;
    }
    tbody.innerHTML = empData.map((e, i) => `
      <tr>
        <td>${i + 1}</td>
        <td><div class="fw-semibold">${e.fullName}</div><div class="text-muted small">${e.cnic || ''}</div></td>
        <td>${e.designation || '—'}</td>
        <td><span class="badge bg-secondary">${e.department || '—'}</span></td>
        <td>${e.phone}</td>
        <td>${e.email || '—'}</td>
        <td class="fw-semibold">${App.formatCurrency(e.salary || 0)}</td>
        <td>${App.formatDate(e.joinDate)}</td>
        <td><span class="badge badge-status ${e.status === 'Active' ? 'bg-success' : 'bg-secondary'}">${e.status}</span></td>
        <td>
          <button class="btn btn-sm btn-outline-primary me-1" onclick="editEmployee(${e.id})"><i class="bi bi-pencil-fill"></i></button>
          <button class="btn btn-sm btn-outline-danger" onclick="deleteEmployee(${e.id}, '${e.fullName}')"><i class="bi bi-trash-fill"></i></button>
        </td>
      </tr>`).join('');
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="10" class="text-center text-danger py-4">${err.message}</td></tr>`;
  }
}

function openAddModal() {
  document.getElementById('empModalTitle').textContent = 'Add Employee';
  document.getElementById('empForm').reset();
  document.getElementById('empForm').classList.remove('was-validated');
  document.getElementById('empId').value = '';
  document.getElementById('modalAlert').classList.add('d-none');
}

function editEmployee(id) {
  const e = empData.find(x => x.id === id);
  if (!e) return;
  document.getElementById('empModalTitle').textContent = 'Edit Employee';
  document.getElementById('empId').value          = e.id;
  document.getElementById('empName').value        = e.fullName;
  document.getElementById('empCnic').value        = e.cnic || '';
  document.getElementById('empPhone').value       = e.phone;
  document.getElementById('empEmail').value       = e.email || '';
  document.getElementById('empDesignation').value = e.designation || '';
  document.getElementById('empDept').value        = e.department || 'Sales';
  document.getElementById('empSalary').value      = e.salary || '';
  document.getElementById('empJoinDate').value    = e.joinDate?.split('T')[0] || '';
  document.getElementById('empStatus').value      = e.status;
  document.getElementById('empAddress').value     = e.address || '';
  document.getElementById('modalAlert').classList.add('d-none');
  document.getElementById('empForm').classList.remove('was-validated');
  modal().show();
}

async function saveEmployee() {
  const form = document.getElementById('empForm');
  form.classList.add('was-validated');
  if (!form.checkValidity()) return;

  const id = document.getElementById('empId').value;
  const payload = {
    fullName:    document.getElementById('empName').value.trim(),
    cnic:        document.getElementById('empCnic').value.trim(),
    phone:       document.getElementById('empPhone').value.trim(),
    email:       document.getElementById('empEmail').value.trim(),
    designation: document.getElementById('empDesignation').value.trim(),
    department:  document.getElementById('empDept').value,
    salary:      parseFloat(document.getElementById('empSalary').value) || 0,
    joinDate:    document.getElementById('empJoinDate').value,
    status:      document.getElementById('empStatus').value,
    address:     document.getElementById('empAddress').value.trim(),
  };

  const btn = document.getElementById('saveEmpBtn');
  const spinner = document.getElementById('saveSpinner');
  btn.disabled = true; spinner.classList.remove('d-none');

  try {
    if (id) { await Api.employees.update(id, payload); App.toast('Employee updated.', 'success'); }
    else    { await Api.employees.create(payload);     App.toast('Employee added.', 'success'); }
    modal().hide();
    await loadEmployees();
  } catch (err) {
    const a = document.getElementById('modalAlert');
    a.className = 'alert alert-danger'; a.textContent = err.message; a.classList.remove('d-none');
  } finally { btn.disabled = false; spinner.classList.add('d-none'); }
}

function deleteEmployee(id, name) {
  App.confirm(`Delete employee "<strong>${name}</strong>"?`, async () => {
    try { await Api.employees.delete(id); App.toast('Employee deleted.', 'success'); await loadEmployees(); }
    catch (err) { App.toast(err.message, 'danger'); }
  });
}
