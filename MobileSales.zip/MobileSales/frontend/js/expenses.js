/* ===== EXPENSES PAGE ===== */
let expensesData = [];
const modal = () => bootstrap.Modal.getOrCreateInstance(document.getElementById('expenseModal'));

document.addEventListener('DOMContentLoaded', async () => {
  App.init('Expenses', 'expenses');
  App.initTableSearch('searchInput', 'expensesTable');
  await loadExpenses();
  document.getElementById('saveExpenseBtn').addEventListener('click', saveExpense);
  document.getElementById('expDate').value = new Date().toISOString().split('T')[0];
  document.getElementById('categoryFilter').addEventListener('change', function () {
    const cat = this.value.toLowerCase();
    document.querySelectorAll('#expensesTable tbody tr').forEach(row => {
      row.style.display = !cat || row.textContent.toLowerCase().includes(cat) ? '' : 'none';
    });
  });
});

async function loadExpenses() {
  const tbody = document.getElementById('expensesBody');
  try {
    expensesData = await Api.expenses.getAll();
    if (!expensesData.length) {
      tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted py-4">No expenses found.</td></tr>';
      updateSummary([]);
      return;
    }
    tbody.innerHTML = expensesData.map((e, i) => `
      <tr>
        <td>${i + 1}</td>
        <td class="fw-semibold">${e.title}</td>
        <td><span class="badge bg-secondary">${e.category}</span></td>
        <td class="fw-bold text-danger">${App.formatCurrency(e.amount)}</td>
        <td>${App.formatDate(e.expenseDate)}</td>
        <td>${e.paidBy || '—'}</td>
        <td class="text-muted small">${e.notes || '—'}</td>
        <td>
          <button class="btn btn-sm btn-outline-primary me-1" onclick="editExpense(${e.id})"><i class="bi bi-pencil-fill"></i></button>
          <button class="btn btn-sm btn-outline-danger" onclick="deleteExpense(${e.id})"><i class="bi bi-trash-fill"></i></button>
        </td>
      </tr>`).join('');
    updateSummary(expensesData);
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="8" class="text-center text-danger py-4">${err.message}</td></tr>`;
  }
}

function updateSummary(data) {
  const total = data.reduce((a, e) => a + e.amount, 0);
  const now = new Date();
  const monthly = data.filter(e => {
    const d = new Date(e.expenseDate);
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  }).reduce((a, e) => a + e.amount, 0);
  document.getElementById('totalExpenses').textContent = App.formatCurrency(total);
  document.getElementById('monthExpenses').textContent = App.formatCurrency(monthly);
}

function openAddModal() {
  document.getElementById('expenseModalTitle').textContent = 'Add Expense';
  document.getElementById('expenseForm').reset();
  document.getElementById('expenseForm').classList.remove('was-validated');
  document.getElementById('expenseId').value = '';
  document.getElementById('expDate').value = new Date().toISOString().split('T')[0];
  document.getElementById('modalAlert').classList.add('d-none');
}

function editExpense(id) {
  const e = expensesData.find(x => x.id === id);
  if (!e) return;
  document.getElementById('expenseModalTitle').textContent = 'Edit Expense';
  document.getElementById('expenseId').value  = e.id;
  document.getElementById('expTitle').value   = e.title;
  document.getElementById('expCategory').value= e.category;
  document.getElementById('expAmount').value  = e.amount;
  document.getElementById('expDate').value    = e.expenseDate?.split('T')[0];
  document.getElementById('expPaidBy').value  = e.paidBy || '';
  document.getElementById('expNotes').value   = e.notes || '';
  document.getElementById('modalAlert').classList.add('d-none');
  document.getElementById('expenseForm').classList.remove('was-validated');
  modal().show();
}

async function saveExpense() {
  const form = document.getElementById('expenseForm');
  form.classList.add('was-validated');
  if (!form.checkValidity()) return;

  const id = document.getElementById('expenseId').value;
  const payload = {
    title:       document.getElementById('expTitle').value.trim(),
    category:    document.getElementById('expCategory').value,
    amount:      parseFloat(document.getElementById('expAmount').value),
    expenseDate: document.getElementById('expDate').value,
    paidBy:      document.getElementById('expPaidBy').value.trim(),
    notes:       document.getElementById('expNotes').value.trim(),
  };

  const btn = document.getElementById('saveExpenseBtn');
  const spinner = document.getElementById('saveSpinner');
  btn.disabled = true; spinner.classList.remove('d-none');

  try {
    if (id) { await Api.expenses.update(id, payload); App.toast('Expense updated.', 'success'); }
    else    { await Api.expenses.create(payload);     App.toast('Expense added.', 'success'); }
    modal().hide();
    await loadExpenses();
  } catch (err) {
    const a = document.getElementById('modalAlert');
    a.className = 'alert alert-danger'; a.textContent = err.message; a.classList.remove('d-none');
  } finally { btn.disabled = false; spinner.classList.add('d-none'); }
}

function deleteExpense(id) {
  App.confirm('Delete this expense?', async () => {
    try { await Api.expenses.delete(id); App.toast('Expense deleted.', 'success'); await loadExpenses(); }
    catch (err) { App.toast(err.message, 'danger'); }
  });
}
