/* ===== INVENTORY PAGE ===== */
let inventoryData = [];
const adjustModal = () => bootstrap.Modal.getOrCreateInstance(document.getElementById('adjustModal'));

document.addEventListener('DOMContentLoaded', async () => {
  App.init('Inventory / Stock', 'inventory');
  App.initTableSearch('searchInput', 'inventoryTable');
  await loadInventory();
  document.getElementById('saveAdjustBtn').addEventListener('click', saveAdjust);
  document.getElementById('stockFilter').addEventListener('change', filterStock);
});

async function loadInventory() {
  const tbody = document.getElementById('inventoryBody');
  try {
    inventoryData = await Api.inventory.getAll();
    renderTable(inventoryData);
    updateSummary(inventoryData);
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="9" class="text-center text-danger py-4">${err.message}</td></tr>`;
  }
}

function renderTable(data) {
  const tbody = document.getElementById('inventoryBody');
  if (!data.length) {
    tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted py-4">No inventory records.</td></tr>';
    return;
  }
  tbody.innerHTML = data.map((item, i) => {
    const isLow  = item.currentStock > 0 && item.currentStock <= item.minStock;
    const isOut  = item.currentStock === 0;
    const stockBadge = isOut  ? '<span class="badge bg-danger">Out of Stock</span>'
                     : isLow  ? '<span class="badge bg-warning text-dark">Low Stock</span>'
                     :          '<span class="badge bg-success">In Stock</span>';
    const stockClass = isOut ? 'text-danger fw-bold' : isLow ? 'text-warning fw-bold' : 'text-success fw-semibold';
    return `
    <tr>
      <td>${i + 1}</td>
      <td class="fw-semibold">${item.productName}</td>
      <td><span class="badge bg-info text-dark">${item.category || '—'}</span></td>
      <td class="${stockClass}">${item.currentStock}</td>
      <td class="text-muted">${item.minStock}</td>
      <td>${App.formatCurrency(item.stockValue || 0)}</td>
      <td>${App.formatDate(item.lastUpdated)}</td>
      <td>${stockBadge}</td>
      <td>
        <button class="btn btn-sm btn-outline-primary" onclick="openAdjust(${item.id}, '${item.productName}', ${item.currentStock})" title="Adjust Stock">
          <i class="bi bi-pencil-square"></i>
        </button>
      </td>
    </tr>`;
  }).join('');
}

function updateSummary(data) {
  document.getElementById('totalItems').textContent   = data.length;
  document.getElementById('inStockItems').textContent = data.filter(i => i.currentStock > i.minStock).length;
  document.getElementById('lowStockItems').textContent= data.filter(i => i.currentStock <= i.minStock).length;
  document.getElementById('stockValue').textContent   = App.formatCurrency(data.reduce((a, i) => a + (i.stockValue || 0), 0));
}

function filterStock() {
  const filter = document.getElementById('stockFilter').value;
  document.querySelectorAll('#inventoryTable tbody tr').forEach(row => {
    const text = row.textContent.toLowerCase();
    if (!filter) { row.style.display = ''; return; }
    if (filter === 'low')  row.style.display = text.includes('low stock') ? '' : 'none';
    if (filter === 'out')  row.style.display = text.includes('out of stock') ? '' : 'none';
    if (filter === 'ok')   row.style.display = text.includes('in stock') ? '' : 'none';
  });
}

function openAdjust(id, name, currentQty) {
  document.getElementById('adjustId').value          = id;
  document.getElementById('adjustProductName').textContent = name;
  document.getElementById('adjustQty').value         = currentQty;
  document.getElementById('adjustReason').value      = '';
  document.getElementById('adjustAlert').classList.add('d-none');
  adjustModal().show();
}

async function saveAdjust() {
  const id  = document.getElementById('adjustId').value;
  const qty = parseInt(document.getElementById('adjustQty').value);
  if (isNaN(qty) || qty < 0) {
    const a = document.getElementById('adjustAlert');
    a.className = 'alert alert-danger'; a.textContent = 'Enter a valid quantity.'; a.classList.remove('d-none');
    return;
  }

  const btn = document.getElementById('saveAdjustBtn');
  const spinner = document.getElementById('adjustSpinner');
  btn.disabled = true; spinner.classList.remove('d-none');

  try {
    await Api.inventory.update(id, {
      currentStock: qty,
      reason: document.getElementById('adjustReason').value.trim(),
    });
    App.toast('Stock updated.', 'success');
    adjustModal().hide();
    await loadInventory();
  } catch (err) {
    const a = document.getElementById('adjustAlert');
    a.className = 'alert alert-danger'; a.textContent = err.message; a.classList.remove('d-none');
  } finally { btn.disabled = false; spinner.classList.add('d-none'); }
}
