/* ===== LOGIN PAGE LOGIC ===== */

document.addEventListener('DOMContentLoaded', () => {
  // Redirect if already logged in
  if (Api.isLoggedIn()) {
    window.location.href = 'dashboard.html';
    return;
  }

  const loginForm      = document.getElementById('loginForm');
  const loginBtn       = document.getElementById('loginBtn');
  const loginSpinner   = document.getElementById('loginSpinner');
  const alertBox       = document.getElementById('alertBox');
  const togglePassword = document.getElementById('togglePassword');
  const eyeIcon        = document.getElementById('eyeIcon');
  const passwordInput  = document.getElementById('password');

  // Toggle password visibility
  togglePassword.addEventListener('click', () => {
    const isText = passwordInput.type === 'text';
    passwordInput.type = isText ? 'password' : 'text';
    eyeIcon.className = isText ? 'bi bi-eye-fill' : 'bi bi-eye-slash-fill';
  });

  // Login form submit
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    loginForm.classList.add('was-validated');

    if (!loginForm.checkValidity()) return;

    const username   = document.getElementById('username').value.trim();
    const password   = passwordInput.value;
    const rememberMe = document.getElementById('rememberMe').checked;

    setLoading(true);
    hideAlert();

    try {
      const res = await Api.auth.login({ username, password });

      Api.setSession(res.token, res.user, rememberMe);

      // First login — force password change
      if (res.user.mustChangePassword) {
        showChangePasswordModal(res.user.id);
      } else {
        redirectByRole(res.user.role);
      }
    } catch (err) {
      showAlert(err.message || 'Invalid username or password.', 'danger');
    } finally {
      setLoading(false);
    }
  });

  // Change password modal
  const cpModal      = new bootstrap.Modal(document.getElementById('changePasswordModal'));
  const savePasswordBtn = document.getElementById('savePasswordBtn');
  const cpSpinner    = document.getElementById('cpSpinner');
  const cpAlertBox   = document.getElementById('cpAlertBox');
  let currentUserId  = null;

  function showChangePasswordModal(userId) {
    currentUserId = userId;
    cpModal.show();
  }

  savePasswordBtn.addEventListener('click', async () => {
    const newPwd     = document.getElementById('newPassword').value;
    const confirmPwd = document.getElementById('confirmPassword').value;
    const form       = document.getElementById('changePasswordForm');

    form.classList.add('was-validated');

    if (newPwd.length < 8) {
      showCpAlert('Password must be at least 8 characters.', 'danger');
      return;
    }

    if (newPwd !== confirmPwd) {
      document.getElementById('confirmPassword').setCustomValidity('mismatch');
      showCpAlert('Passwords do not match.', 'danger');
      return;
    }

    document.getElementById('confirmPassword').setCustomValidity('');

    cpSpinner.classList.remove('d-none');
    savePasswordBtn.disabled = true;

    try {
      await Api.auth.changePassword({ userId: currentUserId, newPassword: newPwd });
      cpModal.hide();
      const user = Api.getUser();
      user.mustChangePassword = false;
      Api.setSession(Api.getToken(), user, !!localStorage.getItem('mp_token'));
      redirectByRole(user.role);
    } catch (err) {
      showCpAlert(err.message || 'Failed to change password.', 'danger');
    } finally {
      cpSpinner.classList.add('d-none');
      savePasswordBtn.disabled = false;
    }
  });

  /* ---- Helpers ---- */
  function setLoading(state) {
    loginSpinner.classList.toggle('d-none', !state);
    loginBtn.disabled = state;
  }

  function showAlert(msg, type) {
    alertBox.className = `alert alert-${type}`;
    alertBox.innerHTML = `<i class="bi bi-exclamation-triangle-fill me-2"></i>${msg}`;
    alertBox.classList.remove('d-none');
  }

  function hideAlert() {
    alertBox.classList.add('d-none');
  }

  function showCpAlert(msg, type) {
    cpAlertBox.className = `alert alert-${type}`;
    cpAlertBox.textContent = msg;
    cpAlertBox.classList.remove('d-none');
  }

  function redirectByRole(role) {
    window.location.href = 'dashboard.html';
  }
});
