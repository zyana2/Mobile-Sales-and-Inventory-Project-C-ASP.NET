/* ===== PRODUCTS PAGE ===== */
let productsData = [];
const modal = () => bootstrap.Modal.getOrCreateInstance(document.getElementById('productModal'));

document.addEventListener('DOMContentLoaded', async () => {
  App.init('Products', 'products');
  App.initTableSearch('searchInput', 'productsTable');
  await loadProducts();

  document.getElementById('saveProductBtn').addEventListener('click', saveProduct);

  document.getElementById('categoryFilter').addEventListener('change', function () {
    const cat = this.value.toLowerCase();
    document.querySelectorAll('#productsTable tbody tr').forEach(row => {
      row.style.display = !cat || row.textContent.toLowerCase().includes(cat) ? '' : 'none';
    });
  });
});

async function loadProducts() {
  const tbody = document.getElementById('productsBody');
  try {
    productsData = await Api.products.getAll();
    renderTable(productsData);
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="10" class="text-center text-danger py-4">${err.message}</td></tr>`;
  }
}

function renderTable(data) {
  const tbody = document.getElementById('productsBody');
  if (!data.length) {
    tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted py-4">No products found.</td></tr>';
    return;
  }
  tbody.innerHTML = data.map((p, i) => {
    const stockClass = p.currentStock <= p.minStock ? 'text-danger fw-bold' : 'text-success fw-semibold';
    return `
    <tr>
      <td>${i + 1}</td>
      <td>
        <div class="fw-semibold">${p.name}</div>
        <div class="text-muted small">${p.sku || ''}</div>
      </td>
      <td><span class="badge bg-info text-dark">${p.category}</span></td>
      <td>${p.brand || '—'}</td>
      <td>${p.model || '—'}</td>
      <td>${App.formatCurrency(p.buyPrice)}</td>
      <td class="fw-semibold">${App.formatCurrency(p.sellPrice)}</td>
      <td class="${stockClass}">${p.currentStock}</td>
      <td><span class="badge badge-status ${p.status === 'Active' ? 'bg-success' : 'bg-secondary'}">${p.status}</span></td>
      <td>
        <button class="btn btn-sm btn-outline-primary me-1" onclick="editProduct(${p.id})" title="Edit">
          <i class="bi bi-pencil-fill"></i>
        </button>
        <button class="btn btn-sm btn-outline-danger" onclick="deleteProduct(${p.id}, '${p.name}')" title="Delete">
          <i class="bi bi-trash-fill"></i>
        </button>
      </td>
    </tr>`;
  }).join('');
}

function openAddModal() {
  document.getElementById('productModalTitle').textContent = 'Add Product';
  document.getElementById('productForm').reset();
  document.getElementById('productForm').classList.remove('was-validated');
  document.getElementById('productId').value = '';
  document.getElementById('modalAlert').classList.add('d-none');
}

function editProduct(id) {
  const p = productsData.find(x => x.id === id);
  if (!p) return;
  document.getElementById('productModalTitle').textContent = 'Edit Product';
  document.getElementById('productId').value        = p.id;
  document.getElementById('prodName').value         = p.name;
  document.getElementById('prodCategory').value     = p.category;
  document.getElementById('prodBrand').value        = p.brand || '';
  document.getElementById('prodModel').value        = p.model || '';
  document.getElementById('prodSku').value          = p.sku || '';
  document.getElementById('prodBuyPrice').value     = p.buyPrice;
  document.getElementById('prodSellPrice').value    = p.sellPrice;
  document.getElementById('prodMinStock').value     = p.minStock;
  document.getElementById('prodWarranty').value     = p.warrantyMonths || 12;
  document.getElementById('prodStatus').value       = p.status;
  document.getElementById('prodDescription').value  = p.description || '';
  document.getElementById('modalAlert').classList.add('d-none');
  document.getElementById('productForm').classList.remove('was-validated');
  modal().show();
}

async function saveProduct() {
  const form = document.getElementById('productForm');
  form.classList.add('was-validated');
  if (!form.checkValidity()) return;

  const id = document.getElementById('productId').value;
  const payload = {
    name:           document.getElementById('prodName').value.trim(),
    category:       document.getElementById('prodCategory').value,
    brand:          document.getElementById('prodBrand').value.trim(),
    model:          document.getElementById('prodModel').value.trim(),
    sku:            document.getElementById('prodSku').value.trim(),
    buyPrice:       parseFloat(document.getElementById('prodBuyPrice').value),
    sellPrice:      parseFloat(document.getElementById('prodSellPrice').value),
    minStock:       parseInt(document.getElementById('prodMinStock').value),
    warrantyMonths: parseInt(document.getElementById('prodWarranty').value),
    status:         document.getElementById('prodStatus').value,
    description:    document.getElementById('prodDescription').value.trim(),
  };

  const btn = document.getElementById('saveProductBtn');
  const spinner = document.getElementById('saveSpinner');
  btn.disabled = true;
  spinner.classList.remove('d-none');

  try {
    if (id) {
      await Api.products.update(id, payload);
      App.toast('Product updated.', 'success');
    } else {
      await Api.products.create(payload);
      App.toast('Product added.', 'success');
    }
    modal().hide();
    await loadProducts();
  } catch (err) {
    const alertBox = document.getElementById('modalAlert');
    alertBox.className = 'alert alert-danger';
    alertBox.textContent = err.message;
    alertBox.classList.remove('d-none');
  } finally {
    btn.disabled = false;
    spinner.classList.add('d-none');
  }
}

function deleteProduct(id, name) {
  App.confirm(`Delete product "<strong>${name}</strong>"?`, async () => {
    try {
      await Api.products.delete(id);
      App.toast('Product deleted.', 'success');
      await loadProducts();
    } catch (err) {
      App.toast(err.message, 'danger');
    }
  });
}
