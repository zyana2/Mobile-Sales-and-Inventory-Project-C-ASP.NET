/* ===== PROFILE PAGE ===== */
let profileData = {};

document.addEventListener('DOMContentLoaded', async () => {
  App.init('My Profile', 'profile');
  await loadProfile();

  document.getElementById('savePersonalBtn').addEventListener('click', savePersonal);
  document.getElementById('changePasswordBtn').addEventListener('click', changePassword);
  document.getElementById('saveEduBtn').addEventListener('click', saveEducation);
  document.getElementById('saveExpBtn').addEventListener('click', saveExperience);
});

async function loadProfile() {
  try {
    profileData = await Api.profile.get();
    fillPersonal(profileData);
    renderEducation(profileData.education || []);
    renderExperience(profileData.experience || []);
    renderCourses(profileData.courses || []);
    renderProjects(profileData.projects || []);
  } catch (err) {
    App.toast('Failed to load profile: ' + err.message, 'danger');
  }
}

function fillPersonal(p) {
  document.getElementById('profileAvatar').textContent = App.getInitials(p.fullName || 'U');
  document.getElementById('profileName').textContent   = p.fullName || '—';
  document.getElementById('profileRole').textContent   = p.role || '—';
  document.getElementById('profileEmail').textContent  = p.email || '—';
  document.getElementById('profilePhone').textContent  = p.phone || '—';
  document.getElementById('profileCity').textContent   = p.city || '—';
  document.getElementById('pFullName').value = p.fullName || '';
  document.getElementById('pPhone').value    = p.phone || '';
  document.getElementById('pEmail').value    = p.email || '';
  document.getElementById('pDob').value      = p.dateOfBirth?.split('T')[0] || '';
  document.getElementById('pCity').value     = p.city || '';
  document.getElementById('pCnic').value     = p.cnic || '';
  document.getElementById('pAddress').value  = p.address || '';
  document.getElementById('pBio').value      = p.bio || '';
}

async function savePersonal() {
  const payload = {
    fullName:    document.getElementById('pFullName').value.trim(),
    phone:       document.getElementById('pPhone').value.trim(),
    email:       document.getElementById('pEmail').value.trim(),
    dateOfBirth: document.getElementById('pDob').value,
    city:        document.getElementById('pCity').value.trim(),
    cnic:        document.getElementById('pCnic').value.trim(),
    address:     document.getElementById('pAddress').value.trim(),
    bio:         document.getElementById('pBio').value.trim(),
  };

  const btn = document.getElementById('savePersonalBtn');
  const spinner = document.getElementById('personalSpinner');
  btn.disabled = true; spinner.classList.remove('d-none');

  try {
    await Api.profile.update(payload);
    App.toast('Profile updated.', 'success');
    document.getElementById('profileName').textContent = payload.fullName;
    document.getElementById('profileEmail').textContent = payload.email;
    document.getElementById('profilePhone').textContent = payload.phone;
    document.getElementById('profileCity').textContent = payload.city;
  } catch (err) {
    const a = document.getElementById('personalAlert');
    a.className = 'alert alert-danger'; a.textContent = err.message; a.classList.remove('d-none');
  } finally { btn.disabled = false; spinner.classList.add('d-none'); }
}

/* ---- Education ---- */
function renderEducation(list) {
  const el = document.getElementById('educationList');
  if (!list.length) { el.innerHTML = '<p class="text-muted">No education records added.</p>'; return; }
  el.innerHTML = list.map(e => `
    <div class="border rounded p-3 mb-2 d-flex justify-content-between align-items-start">
      <div>
        <div class="fw-bold">${e.degree}</div>
        <div class="text-muted small">${e.institution}</div>
        <div class="text-muted small">${App.formatDate(e.fromDate)} – ${e.toDate ? App.formatDate(e.toDate) : 'Present'} ${e.grade ? '| ' + e.grade : ''}</div>
      </div>
      <div>
        <button class="btn btn-sm btn-outline-primary me-1" onclick="editEdu(${e.id})"><i class="bi bi-pencil"></i></button>
        <button class="btn btn-sm btn-outline-danger" onclick="deleteEdu(${e.id})"><i class="bi bi-trash"></i></button>
      </div>
    </div>`).join('');
}

function openEduModal(edu = null) {
  document.getElementById('eduModalTitle').textContent = edu ? 'Edit Education' : 'Add Education';
  document.getElementById('eduForm').reset();
  document.getElementById('eduId').value = edu?.id || '';
  if (edu) {
    document.getElementById('eduDegree').value      = edu.degree;
    document.getElementById('eduInstitution').value = edu.institution;
    document.getElementById('eduFrom').value        = edu.fromDate?.split('T')[0] || '';
    document.getElementById('eduTo').value          = edu.toDate?.split('T')[0] || '';
    document.getElementById('eduGrade').value       = edu.grade || '';
  }
  bootstrap.Modal.getOrCreateInstance(document.getElementById('eduModal')).show();
}

function editEdu(id) {
  const e = (profileData.education || []).find(x => x.id === id);
  if (e) openEduModal(e);
}

async function saveEducation() {
  const form = document.getElementById('eduForm');
  form.classList.add('was-validated');
  if (!form.checkValidity()) return;

  const id = document.getElementById('eduId').value;
  const payload = {
    degree:      document.getElementById('eduDegree').value.trim(),
    institution: document.getElementById('eduInstitution').value.trim(),
    fromDate:    document.getElementById('eduFrom').value,
    toDate:      document.getElementById('eduTo').value,
    grade:       document.getElementById('eduGrade').value.trim(),
  };

  try {
    if (id) await Api.profile.updateEducation(id, payload);
    else    await Api.profile.addEducation(payload);
    App.toast('Education saved.', 'success');
    bootstrap.Modal.getOrCreateInstance(document.getElementById('eduModal')).hide();
    await loadProfile();
  } catch (err) { App.toast(err.message, 'danger'); }
}

async function deleteEdu(id) {
  App.confirm('Delete this education record?', async () => {
    try { await Api.profile.deleteEducation(id); App.toast('Deleted.', 'success'); await loadProfile(); }
    catch (err) { App.toast(err.message, 'danger'); }
  });
}

/* ---- Experience ---- */
function renderExperience(list) {
  const el = document.getElementById('experienceList');
  if (!list.length) { el.innerHTML = '<p class="text-muted">No experience records added.</p>'; return; }
  el.innerHTML = list.map(e => `
    <div class="border rounded p-3 mb-2 d-flex justify-content-between align-items-start">
      <div>
        <div class="fw-bold">${e.jobTitle}</div>
        <div class="text-muted small">${e.company}</div>
        <div class="text-muted small">${App.formatDate(e.fromDate)} – ${e.isCurrent ? 'Present' : App.formatDate(e.toDate)}</div>
        ${e.description ? `<div class="small mt-1">${e.description}</div>` : ''}
      </div>
      <div>
        <button class="btn btn-sm btn-outline-primary me-1" onclick="editExp(${e.id})"><i class="bi bi-pencil"></i></button>
        <button class="btn btn-sm btn-outline-danger" onclick="deleteExp(${e.id})"><i class="bi bi-trash"></i></button>
      </div>
    </div>`).join('');
}

function openExpModal(exp = null) {
  document.getElementById('expModalTitle').textContent = exp ? 'Edit Experience' : 'Add Experience';
  document.getElementById('expForm').reset();
  document.getElementById('expId').value = exp?.id || '';
  if (exp) {
    document.getElementById('expTitle').value   = exp.jobTitle;
    document.getElementById('expCompany').value = exp.company;
    document.getElementById('expFrom').value    = exp.fromDate?.split('T')[0] || '';
    document.getElementById('expTo').value      = exp.toDate?.split('T')[0] || '';
    document.getElementById('expCurrent').checked = exp.isCurrent;
    document.getElementById('expDesc').value    = exp.description || '';
  }
  bootstrap.Modal.getOrCreateInstance(document.getElementById('expModal')).show();
}

function editExp(id) {
  const e = (profileData.experience || []).find(x => x.id === id);
  if (e) openExpModal(e);
}

async function saveExperience() {
  const form = document.getElementById('expForm');
  form.classList.add('was-validated');
  if (!form.checkValidity()) return;

  const id = document.getElementById('expId').value;
  const payload = {
    jobTitle:    document.getElementById('expTitle').value.trim(),
    company:     document.getElementById('expCompany').value.trim(),
    fromDate:    document.getElementById('expFrom').value,
    toDate:      document.getElementById('expTo').value,
    isCurrent:   document.getElementById('expCurrent').checked,
    description: document.getElementById('expDesc').value.trim(),
  };

  try {
    if (id) await Api.profile.updateExperience(id, payload);
    else    await Api.profile.addExperience(payload);
    App.toast('Experience saved.', 'success');
    bootstrap.Modal.getOrCreateInstance(document.getElementById('expModal')).hide();
    await loadProfile();
  } catch (err) { App.toast(err.message, 'danger'); }
}

async function deleteExp(id) {
  App.confirm('Delete this experience record?', async () => {
    try { await Api.profile.deleteExperience(id); App.toast('Deleted.', 'success'); await loadProfile(); }
    catch (err) { App.toast(err.message, 'danger'); }
  });
}

/* ---- Courses (simple inline add) ---- */
function renderCourses(list) {
  const el = document.getElementById('coursesList');
  if (!list.length) { el.innerHTML = '<p class="text-muted">No courses added.</p>'; return; }
  el.innerHTML = list.map(c => `
    <div class="border rounded p-3 mb-2 d-flex justify-content-between align-items-center">
      <div>
        <div class="fw-bold">${c.courseName}</div>
        <div class="text-muted small">${c.provider || ''} ${c.completionDate ? '| ' + App.formatDate(c.completionDate) : ''}</div>
      </div>
    </div>`).join('');
}

function openCourseModal() { App.toast('Course management coming soon.', 'info'); }

/* ---- Projects ---- */
function renderProjects(list) {
  const el = document.getElementById('projectsList');
  if (!list.length) { el.innerHTML = '<p class="text-muted">No projects added.</p>'; return; }
  el.innerHTML = list.map(p => `
    <div class="border rounded p-3 mb-2">
      <div class="fw-bold">${p.title}</div>
      <div class="text-muted small">${p.description || ''}</div>
      ${p.url ? `<a href="${p.url}" target="_blank" class="small"><i class="bi bi-link-45deg"></i> View</a>` : ''}
    </div>`).join('');
}

function openProjectModal() { App.toast('Project management coming soon.', 'info'); }

/* ---- Change Password ---- */
async function changePassword() {
  const form = document.getElementById('securityForm');
  form.classList.add('was-validated');

  const current = document.getElementById('secCurrentPwd').value;
  const newPwd  = document.getElementById('secNewPwd').value;
  const confirm = document.getElementById('secConfirmPwd').value;

  if (!current || newPwd.length < 8) return;
  if (newPwd !== confirm) {
    App.toast('Passwords do not match.', 'danger'); return;
  }

  const btn = document.getElementById('changePasswordBtn');
  const spinner = document.getElementById('secSpinner');
  btn.disabled = true; spinner.classList.remove('d-none');

  try {
    await Api.auth.changePassword({ currentPassword: current, newPassword: newPwd });
    App.toast('Password changed successfully.', 'success');
    form.reset();
    form.classList.remove('was-validated');
  } catch (err) {
    const a = document.getElementById('securityAlert');
    a.className = 'alert alert-danger'; a.textContent = err.message; a.classList.remove('d-none');
  } finally { btn.disabled = false; spinner.classList.add('d-none'); }
}
