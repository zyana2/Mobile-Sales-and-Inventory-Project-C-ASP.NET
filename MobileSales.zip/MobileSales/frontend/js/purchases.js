/* ===== PURCHASES PAGE ===== */
let purchasesData = [];
const modal = () => bootstrap.Modal.getOrCreateInstance(document.getElementById('purchaseModal'));

document.addEventListener('DOMContentLoaded', async () => {
  App.init('Purchases', 'purchases');
  App.initTableSearch('searchInput', 'purchasesTable');
  await loadPurchases();
  await loadProductDropdown();
  document.getElementById('savePurchaseBtn').addEventListener('click', savePurchase);
  document.getElementById('purDate').value = new Date().toISOString().split('T')[0];
});

async function loadProductDropdown() {
  try {
    const products = await Api.products.getAll();
    const sel = document.getElementById('purProduct');
    products.filter(p => p.status === 'Active').forEach(p => {
      sel.insertAdjacentHTML('beforeend', `<option value="${p.id}">${p.name}</option>`);
    });
  } catch (_) {}
}

async function loadPurchases() {
  const tbody = document.getElementById('purchasesBody');
  try {
    purchasesData = await Api.purchases.getAll();
    if (!purchasesData.length) {
      tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted py-4">No purchases found.</td></tr>';
      return;
    }
    tbody.innerHTML = purchasesData.map((p, i) => `
      <tr>
        <td>${i + 1}</td>
        <td>${p.supplierName}</td>
        <td>${p.productName}</td>
        <td>${p.quantity}</td>
        <td>${App.formatCurrency(p.unitCost)}</td>
        <td class="fw-bold">${App.formatCurrency(p.totalCost)}</td>
        <td>${App.formatDate(p.purchaseDate)}</td>
        <td><span class="badge badge-status ${p.status === 'Received' ? 'bg-success' : p.status === 'Pending' ? 'bg-warning text-dark' : 'bg-danger'}">${p.status}</span></td>
        <td>
          <button class="btn btn-sm btn-outline-primary me-1" onclick="editPurchase(${p.id})"><i class="bi bi-pencil-fill"></i></button>
          <button class="btn btn-sm btn-outline-danger" onclick="deletePurchase(${p.id})"><i class="bi bi-trash-fill"></i></button>
        </td>
      </tr>`).join('');
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="9" class="text-center text-danger py-4">${err.message}</td></tr>`;
  }
}

function calcPurTotal() {
  const qty  = parseFloat(document.getElementById('purQty').value) || 0;
  const cost = parseFloat(document.getElementById('purUnitCost').value) || 0;
  document.getElementById('purTotal').value = qty * cost;
}

function openAddModal() {
  document.getElementById('purchaseModalTitle').textContent = 'New Purchase';
  document.getElementById('purchaseForm').reset();
  document.getElementById('purchaseForm').classList.remove('was-validated');
  document.getElementById('purchaseId').value = '';
  document.getElementById('purDate').value = new Date().toISOString().split('T')[0];
  document.getElementById('modalAlert').classList.add('d-none');
}

function editPurchase(id) {
  const p = purchasesData.find(x => x.id === id);
  if (!p) return;
  document.getElementById('purchaseModalTitle').textContent = 'Edit Purchase';
  document.getElementById('purchaseId').value   = p.id;
  document.getElementById('purSupplier').value  = p.supplierName;
  document.getElementById('purProduct').value   = p.productId;
  document.getElementById('purQty').value       = p.quantity;
  document.getElementById('purUnitCost').value  = p.unitCost;
  document.getElementById('purTotal').value     = p.totalCost;
  document.getElementById('purDate').value      = p.purchaseDate?.split('T')[0];
  document.getElementById('purInvoice').value   = p.invoiceNumber || '';
  document.getElementById('purStatus').value    = p.status;
  document.getElementById('purNotes').value     = p.notes || '';
  document.getElementById('modalAlert').classList.add('d-none');
  document.getElementById('purchaseForm').classList.remove('was-validated');
  modal().show();
}

async function savePurchase() {
  const form = document.getElementById('purchaseForm');
  form.classList.add('was-validated');
  if (!form.checkValidity()) return;

  const id = document.getElementById('purchaseId').value;
  const payload = {
    supplierName:  document.getElementById('purSupplier').value.trim(),
    productId:     parseInt(document.getElementById('purProduct').value),
    quantity:      parseInt(document.getElementById('purQty').value),
    unitCost:      parseFloat(document.getElementById('purUnitCost').value),
    totalCost:     parseFloat(document.getElementById('purTotal').value),
    purchaseDate:  document.getElementById('purDate').value,
    invoiceNumber: document.getElementById('purInvoice').value.trim(),
    status:        document.getElementById('purStatus').value,
    notes:         document.getElementById('purNotes').value.trim(),
  };

  const btn = document.getElementById('savePurchaseBtn');
  const spinner = document.getElementById('saveSpinner');
  btn.disabled = true; spinner.classList.remove('d-none');

  try {
    if (id) { await Api.purchases.update(id, payload); App.toast('Purchase updated.', 'success'); }
    else    { await Api.purchases.create(payload);     App.toast('Purchase recorded.', 'success'); }
    modal().hide();
    await loadPurchases();
  } catch (err) {
    const a = document.getElementById('modalAlert');
    a.className = 'alert alert-danger'; a.textContent = err.message; a.classList.remove('d-none');
  } finally { btn.disabled = false; spinner.classList.add('d-none'); }
}

function deletePurchase(id) {
  App.confirm('Delete this purchase record?', async () => {
    try { await Api.purchases.delete(id); App.toast('Purchase deleted.', 'success'); await loadPurchases(); }
    catch (err) { App.toast(err.message, 'danger'); }
  });
}
