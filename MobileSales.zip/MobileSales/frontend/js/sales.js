/* ===== SALES PAGE ===== */
let salesData = [];
let productsCache = [];
let customersCache = [];
const modal = () => bootstrap.Modal.getOrCreateInstance(document.getElementById('saleModal'));

document.addEventListener('DOMContentLoaded', async () => {
  App.init('Sales', 'sales');
  App.initTableSearch('searchInput', 'salesTable');

  // Set today's date as default
  document.getElementById('saleDate').value = new Date().toISOString().split('T')[0];

  await Promise.all([loadSales(), loadDropdowns()]);

  document.getElementById('saveSaleBtn').addEventListener('click', saveSale);
  document.getElementById('dateFrom').addEventListener('change', filterByDate);
  document.getElementById('dateTo').addEventListener('change', filterByDate);
});

async function loadDropdowns() {
  try {
    [customersCache, productsCache] = await Promise.all([Api.customers.getAll(), Api.products.getAll()]);

    const custSel = document.getElementById('saleCustomer');
    customersCache.forEach(c => {
      custSel.insertAdjacentHTML('beforeend', `<option value="${c.id}">${c.fullName} - ${c.phone}</option>`);
    });

    const prodSel = document.getElementById('saleProduct');
    productsCache.filter(p => p.status === 'Active').forEach(p => {
      prodSel.insertAdjacentHTML('beforeend', `<option value="${p.id}" data-price="${p.sellPrice}" data-stock="${p.currentStock}">${p.name} (Stock: ${p.currentStock})</option>`);
    });
  } catch (err) {
    console.error('Dropdown error:', err);
  }
}

async function loadSales() {
  const tbody = document.getElementById('salesBody');
  try {
    salesData = await Api.sales.getAll();
    renderTable(salesData);
    updateSummary(salesData);
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="12" class="text-center text-danger py-4">${err.message}</td></tr>`;
  }
}

function renderTable(data) {
  const tbody = document.getElementById('salesBody');
  if (!data.length) {
    tbody.innerHTML = '<tr><td colspan="12" class="text-center text-muted py-4">No sales records found.</td></tr>';
    return;
  }
  tbody.innerHTML = data.map((s, i) => `
    <tr>
      <td>${i + 1}</td>
      <td class="fw-semibold text-primary">${s.invoiceNumber || 'INV-' + s.id}</td>
      <td>${s.customerName}</td>
      <td>${s.productName}</td>
      <td>${s.quantity}</td>
      <td>${App.formatCurrency(s.unitPrice)}</td>
      <td>${s.discount ? App.formatCurrency(s.discount) : '—'}</td>
      <td class="fw-bold">${App.formatCurrency(s.totalAmount)}</td>
      <td class="text-success fw-semibold">${App.formatCurrency(s.profit || 0)}</td>
      <td>${App.formatDate(s.saleDate)}</td>
      <td><span class="badge badge-status ${statusClass(s.status)}">${s.status}</span></td>
      <td>
        <button class="btn btn-sm btn-outline-primary me-1" onclick="editSale(${s.id})" title="Edit">
          <i class="bi bi-pencil-fill"></i>
        </button>
        <button class="btn btn-sm btn-outline-danger" onclick="deleteSale(${s.id})" title="Delete">
          <i class="bi bi-trash-fill"></i>
        </button>
      </td>
    </tr>`).join('');
}

function statusClass(s) {
  return s === 'Completed' ? 'bg-success' : s === 'Pending' ? 'bg-warning text-dark' : 'bg-danger';
}

function updateSummary(data) {
  const completed = data.filter(s => s.status === 'Completed');
  document.getElementById('totalSalesCount').textContent = data.length;
  document.getElementById('totalRevenue').textContent    = App.formatCurrency(completed.reduce((a, s) => a + s.totalAmount, 0));
  document.getElementById('totalProfit').textContent     = App.formatCurrency(completed.reduce((a, s) => a + (s.profit || 0), 0));
  const today = new Date().toDateString();
  document.getElementById('todaySales').textContent = data.filter(s => new Date(s.saleDate).toDateString() === today).length;
}

function filterByDate() {
  const from = document.getElementById('dateFrom').value;
  const to   = document.getElementById('dateTo').value;
  const filtered = salesData.filter(s => {
    const d = s.saleDate?.split('T')[0];
    return (!from || d >= from) && (!to || d <= to);
  });
  renderTable(filtered);
}

function onProductChange() {
  const sel = document.getElementById('saleProduct');
  const opt = sel.options[sel.selectedIndex];
  document.getElementById('saleUnitPrice').value = opt.dataset.price || '';
  calcTotal();
}

function calcTotal() {
  const qty      = parseFloat(document.getElementById('saleQty').value) || 0;
  const price    = parseFloat(document.getElementById('saleUnitPrice').value) || 0;
  const discount = parseFloat(document.getElementById('saleDiscount').value) || 0;
  document.getElementById('saleTotalAmount').value = Math.max(0, qty * price - discount);
}

function openAddModal() {
  document.getElementById('saleModalTitle').textContent = 'New Sale';
  document.getElementById('saleForm').reset();
  document.getElementById('saleForm').classList.remove('was-validated');
  document.getElementById('saleId').value = '';
  document.getElementById('saleDate').value = new Date().toISOString().split('T')[0];
  document.getElementById('modalAlert').classList.add('d-none');
}

function editSale(id) {
  const s = salesData.find(x => x.id === id);
  if (!s) return;
  document.getElementById('saleModalTitle').textContent = 'Edit Sale';
  document.getElementById('saleId').value          = s.id;
  document.getElementById('saleCustomer').value    = s.customerId;
  document.getElementById('saleProduct').value     = s.productId;
  document.getElementById('saleQty').value         = s.quantity;
  document.getElementById('saleUnitPrice').value   = s.unitPrice;
  document.getElementById('saleDiscount').value    = s.discount || 0;
  document.getElementById('saleTotalAmount').value = s.totalAmount;
  document.getElementById('saleDate').value        = s.saleDate?.split('T')[0];
  document.getElementById('salePayment').value     = s.paymentMethod;
  document.getElementById('saleStatus').value      = s.status;
  document.getElementById('saleNotes').value       = s.notes || '';
  document.getElementById('modalAlert').classList.add('d-none');
  document.getElementById('saleForm').classList.remove('was-validated');
  modal().show();
}

async function saveSale() {
  const form = document.getElementById('saleForm');
  form.classList.add('was-validated');
  if (!form.checkValidity()) return;

  const id = document.getElementById('saleId').value;
  const payload = {
    customerId:    parseInt(document.getElementById('saleCustomer').value),
    productId:     parseInt(document.getElementById('saleProduct').value),
    quantity:      parseInt(document.getElementById('saleQty').value),
    unitPrice:     parseFloat(document.getElementById('saleUnitPrice').value),
    discount:      parseFloat(document.getElementById('saleDiscount').value) || 0,
    totalAmount:   parseFloat(document.getElementById('saleTotalAmount').value),
    saleDate:      document.getElementById('saleDate').value,
    paymentMethod: document.getElementById('salePayment').value,
    status:        document.getElementById('saleStatus').value,
    notes:         document.getElementById('saleNotes').value.trim(),
  };

  const btn = document.getElementById('saveSaleBtn');
  const spinner = document.getElementById('saveSpinner');
  btn.disabled = true;
  spinner.classList.remove('d-none');

  try {
    if (id) {
      await Api.sales.update(id, payload);
      App.toast('Sale updated.', 'success');
    } else {
      await Api.sales.create(payload);
      App.toast('Sale recorded.', 'success');
    }
    modal().hide();
    await loadSales();
  } catch (err) {
    const alertBox = document.getElementById('modalAlert');
    alertBox.className = 'alert alert-danger';
    alertBox.textContent = err.message;
    alertBox.classList.remove('d-none');
  } finally {
    btn.disabled = false;
    spinner.classList.add('d-none');
  }
}

function deleteSale(id) {
  App.confirm('Delete this sale record?', async () => {
    try {
      await Api.sales.delete(id);
      App.toast('Sale deleted.', 'success');
      await loadSales();
    } catch (err) {
      App.toast(err.message, 'danger');
    }
  });
}
