/* ===== USER MANAGEMENT PAGE ===== */
let usersData = [];
const modal = () => bootstrap.Modal.getOrCreateInstance(document.getElementById('userModal'));

document.addEventListener('DOMContentLoaded', async () => {
  App.init('User Management', 'users');
  App.initTableSearch('searchInput', 'usersTable');
  await loadUsers();
  document.getElementById('saveUserBtn').addEventListener('click', saveUser);
  generatePassword(); // pre-fill a default password
});

async function loadUsers() {
  const tbody = document.getElementById('usersBody');
  try {
    usersData = await Api.users.getAll();
    if (!usersData.length) {
      tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted py-4">No users found.</td></tr>';
      return;
    }
    tbody.innerHTML = usersData.map((u, i) => `
      <tr>
        <td>${i + 1}</td>
        <td class="fw-semibold"><i class="bi bi-person-circle me-1 text-primary"></i>${u.username}</td>
        <td>${u.fullName}</td>
        <td>${u.email || '—'}</td>
        <td>${roleBadge(u.role)}</td>
        <td><span class="badge badge-status ${u.status === 'Active' ? 'bg-success' : 'bg-secondary'}">${u.status}</span></td>
        <td>${u.lastLogin ? App.formatDate(u.lastLogin) : '<span class="text-muted">Never</span>'}</td>
        <td>
          <button class="btn btn-sm btn-outline-primary me-1" onclick="editUser(${u.id})" title="Edit"><i class="bi bi-pencil-fill"></i></button>
          <button class="btn btn-sm btn-outline-warning me-1" onclick="resetPassword(${u.id}, '${u.username}')" title="Reset Password"><i class="bi bi-key-fill"></i></button>
          <button class="btn btn-sm btn-outline-danger" onclick="deleteUser(${u.id}, '${u.username}')" title="Delete"><i class="bi bi-trash-fill"></i></button>
        </td>
      </tr>`).join('');
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="8" class="text-center text-danger py-4">${err.message}</td></tr>`;
  }
}

function roleBadge(role) {
  const map = { Admin: 'bg-danger', Manager: 'bg-primary', Employee: 'bg-info text-dark', Viewer: 'bg-secondary' };
  return `<span class="badge ${map[role] || 'bg-secondary'}">${role}</span>`;
}

function generatePassword() {
  const chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789@#$';
  let pwd = '';
  for (let i = 0; i < 10; i++) pwd += chars[Math.floor(Math.random() * chars.length)];
  document.getElementById('uPassword').value = pwd;
}

function openAddModal() {
  document.getElementById('userModalTitle').textContent = 'Create User';
  document.getElementById('userForm').reset();
  document.getElementById('userForm').classList.remove('was-validated');
  document.getElementById('userId').value = '';
  document.getElementById('passwordField').style.display = '';
  document.getElementById('modalAlert').classList.add('d-none');
  generatePassword();
}

function editUser(id) {
  const u = usersData.find(x => x.id === id);
  if (!u) return;
  document.getElementById('userModalTitle').textContent = 'Edit User';
  document.getElementById('userId').value    = u.id;
  document.getElementById('uUsername').value = u.username;
  document.getElementById('uFullName').value = u.fullName;
  document.getElementById('uEmail').value    = u.email || '';
  document.getElementById('uRole').value     = u.role;
  document.getElementById('uStatus').value   = u.status;
  document.getElementById('passwordField').style.display = 'none'; // hide on edit
  document.getElementById('modalAlert').classList.add('d-none');
  document.getElementById('userForm').classList.remove('was-validated');
  modal().show();
}

async function saveUser() {
  const form = document.getElementById('userForm');
  form.classList.add('was-validated');
  if (!form.checkValidity()) return;

  const id = document.getElementById('userId').value;
  const payload = {
    username: document.getElementById('uUsername').value.trim(),
    fullName: document.getElementById('uFullName').value.trim(),
    email:    document.getElementById('uEmail').value.trim(),
    role:     document.getElementById('uRole').value,
    status:   document.getElementById('uStatus').value,
  };
  if (!id) payload.password = document.getElementById('uPassword').value;

  const btn = document.getElementById('saveUserBtn');
  const spinner = document.getElementById('saveSpinner');
  btn.disabled = true; spinner.classList.remove('d-none');

  try {
    if (id) { await Api.users.update(id, payload); App.toast('User updated.', 'success'); }
    else    { await Api.users.create(payload);     App.toast('User created. Default password set.', 'success'); }
    modal().hide();
    await loadUsers();
  } catch (err) {
    const a = document.getElementById('modalAlert');
    a.className = 'alert alert-danger'; a.textContent = err.message; a.classList.remove('d-none');
  } finally { btn.disabled = false; spinner.classList.add('d-none'); }
}

function resetPassword(id, username) {
  App.confirm(`Reset password for user "<strong>${username}</strong>"? A new default password will be generated.`, async () => {
    try {
      const res = await Api.users.resetPwd(id);
      App.toast(`Password reset. New password: ${res.newPassword}`, 'warning');
    } catch (err) { App.toast(err.message, 'danger'); }
  });
}

function deleteUser(id, username) {
  App.confirm(`Delete user "<strong>${username}</strong>"? This cannot be undone.`, async () => {
    try { await Api.users.delete(id); App.toast('User deleted.', 'success'); await loadUsers(); }
    catch (err) { App.toast(err.message, 'danger'); }
  });
}
